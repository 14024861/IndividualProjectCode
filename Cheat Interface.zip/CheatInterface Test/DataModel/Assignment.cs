﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Assignment
    {
        string assignmentName;
        List<Submission> assignmentSubmissions = new List<Submission>();
        string staffOwner = null;

        public Assignment(string staffOwner, string assignmentName)
        {
            this.StaffOwner = staffOwner;
            this.assignmentName = assignmentName;
        }

        public string StaffOwner { get => staffOwner; set => staffOwner = value; }
        public string AssignmentName { get => assignmentName; }
        public List<Submission> AssignmentSubmissions  { get => assignmentSubmissions; }

        public void AddSubmission(Submission submission)
        {
            if (!assignmentSubmissions.Contains(submission))
            {
                assignmentSubmissions.Add(submission);
            }
        }
    }
}
