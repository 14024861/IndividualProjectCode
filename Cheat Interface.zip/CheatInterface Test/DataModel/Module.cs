﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Module
    {
        private string moduleName;
        private List<string> moduleAssignmentNames = new List<string>();

        public Module(string moduleName)
        {
            this.moduleName = moduleName;
        }

        public string ModuleName { get => moduleName; set => moduleName = value; }
        public List<string> ModuleAssignmentNames { get => moduleAssignmentNames; set => moduleAssignmentNames = value; }

        public void AddModuleAssignmentName(string assignmentName)
        {
            moduleAssignmentNames.Add(assignmentName);
        }
    }
}