﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Course
    {
        private string courseName;
        private List<string> courseModuleNames = new List<string>();

        public string CourseName { get => courseName;}
        public List<string> CourseModuleNames { get => courseModuleNames; set => courseModuleNames = value; }

        public Course(string courseName)
        {
            this.courseName = courseName;
        }

        public void AddModuleName(string moduleName)
        {
            courseModuleNames.Add(moduleName);
        }
    }


}
