﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Staff : Person
    {
        private string userName;
        private string password;
        private string email;
        private string secretWord;
        private bool isAdmin;
        List<string> coursesTaught = new List<string>();
        List<string> modulesTaught = new List<string>();
        private Dictionary<string, Assignment> assignmentLookup = new Dictionary<string, Assignment>();

        public string UserName { get => userName; }
        public string Password { get => password; set => password = value; }
        public string Email { get => email; set => email = value; }
        public string SecretWord { get => secretWord; set => secretWord = value; }
        public bool IsAdmin { get => isAdmin; set => isAdmin = value; }
        public List<string> CoursesTaught { get => coursesTaught; set => coursesTaught = value; }
        public List<string> ModulesTaught { get => modulesTaught; set => modulesTaught = value; }
        public Dictionary<string, Assignment> AssignmentLookup { get => assignmentLookup; set => assignmentLookup = value; }

        public Staff(string userName, string firstName, string lastName, string password, string email, 
                     string secretWord, bool isAdmin)
        {
            this.userName = userName;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.password = password;
            this.email = email;
            this.secretWord = secretWord;
            this.isAdmin = isAdmin;
        }

        public bool removeAssignment (string assignmentName)
        {
            bool result = false;
            if (this.assignmentLookup.ContainsKey(assignmentName))
            {
                assignmentLookup.Remove(assignmentName);
                result = true;
            }
            return result;
        }

        public Assignment GetAssignment(string assignmentName)
        {
            Assignment result = null;
            if (this.AssignmentLookup.ContainsKey(assignmentName))
            {
                result = this.AssignmentLookup[assignmentName];
            }

            return result;
        }

        public bool AddAssignment(Assignment newAssignment)
        {
            bool success = false;
            if (!this.AssignmentLookup.ContainsKey(newAssignment.AssignmentName))
            {
                AssignmentLookup.Add(newAssignment.AssignmentName, newAssignment);
                success = true;
            }

            return success;
        }
    }
}
