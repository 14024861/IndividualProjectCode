﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Submission
    {
        string submissionURLName;
        string submissionName;
        string submissionDate;
        string percentageSimilarity;
        string studentID;
        string documentName;

        public string SubmissionURL { get => submissionURLName; }
        public string SubmissionName { get => submissionName; }
        public string SubmissionDate { get => submissionDate; }
        public string PercentageSimilarity { get => percentageSimilarity; }
        public string StudentID { get => studentID; }
        public string DocumentName { get => documentName; }

        public Submission(string submissionURL, string submissionName, string submissionDate, string percentageSimilarity, 
                          string studentID, string documentName)
        {
            this.submissionURLName = submissionURL;
            this.submissionName = submissionName;
            this.submissionDate = submissionDate;
            this.percentageSimilarity = percentageSimilarity;
            this.studentID = studentID;
            this.documentName = documentName;
        }
    }
}
