﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Student : Person
    {
        // Username and course can be used to find submissions in the assignments this student is a part of
        // and has submitted to.
        private string studentID;
        private string course;

        public string StudentID { get => studentID; set => studentID = value; }
        public string Course { get => course; set => course = value; }

        public Student(string studentID, string firstName, string lastName,  string course)
        {
            this.studentID = studentID;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.course = course;
        }
    }
}
