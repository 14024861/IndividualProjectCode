﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Person
    {
        private string firstName;
        private string lastName;
        private Guid idNumber;

        public Person()
        {
            this.idNumber = Guid.NewGuid();
        }
        
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public Guid IdNumber { get => idNumber; }
    }
}
