﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    // implements the Singleton pattern.
    public class AccountManager
    {
        private const string filepath = "./accounts.dat";
        private Dictionary<string, Staff> staffAccounts;
        private Dictionary<string, Student> studentAccounts;
        private List<Staff> accountList = new List<Staff>();
        private static AccountManager instance = null;
        private Staff staffLoggedIn = null;
        private Staff staffAccountSelected = null;
        // Set the location that the submissions are stored for future reference.
        private string submissionsFolderURL = Directory.GetCurrentDirectory().Replace(@"CheatInterface Test\bin\Debug", @"Submissions - DoNotDelete\");

        public static AccountManager GetInstance()
        {
            if(instance == null)
            {
                instance = new AccountManager();
            }

            return instance;
        }

        private AccountManager()
        {
            staffAccounts = new Dictionary<string, Staff>();
            StudentAccounts = new Dictionary<string, Student>();
        }

        public Staff accountLoggedIn { get => staffLoggedIn; set => staffLoggedIn = value; }
        public Staff accountSelected { get => staffAccountSelected; set => staffAccountSelected = value; }
        public string SubmissionsFolderURL { get => submissionsFolderURL; set => submissionsFolderURL = value; }
        public Dictionary<string, Student> StudentAccounts { get => studentAccounts; set => studentAccounts = value; }

        // Check for correct number of entries, then if the Email segment has the relevent characters and is unique, then if the IsAdmin field is a bool value.
        // Only then is an assignment added (Checking for account already being present is in CreateAccount()).
        // Text structure is: Username,First Name,Last Name,Password,Email,Secret Word,IsAdmin.
        public bool AcceptStaffFromFile(string fileURL)
        {
            bool success = false;
            if (File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();
                List<string> courses = new List<string>();
                List<string> modules = new List<string>();


                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (entries.Count() == 8)
                    {
                        if (entries[4].Contains("@") && entries[4].Contains(".") && !HasEmail(entries[4]))
                        {
                            if (entries[6] == "False")
                            {
                                // If there are courses or modules attached seperate courses using the = character and then the modules with the - character afterwards
                                // in the last index. Then remove the last index in each list as they are not needed.

                                // Text structure for list: course1 course2 course3 module1-module2-module3-
                                courses = entries[7].Split('=').ToList<string>();

                                // Text structure for list: module1 module2 module3 ""
                                modules = courses[courses.Count - 1].Split('-').ToList<string>();

                                modules.RemoveAt(modules.Count - 1);
                                courses.RemoveAt(courses.Count - 1);

                                // Only add courses and modules that have not yet been added.
                                CreateAccount(entries[0], entries[1], entries[2], entries[3], entries[4], entries[5], false);
                                foreach(string course in courses)
                                {
                                    if (!staffAccounts[entries[0]].CoursesTaught.Contains(course))
                                    {
                                        staffAccounts[entries[0]].CoursesTaught.Add(course);
                                    }
                                }
                                foreach (string module in modules)
                                {
                                    if (!staffAccounts[entries[0]].ModulesTaught.Contains(module))
                                    {
                                        staffAccounts[entries[0]].ModulesTaught.Add(module);
                                    }
                                }
                                success = true;
                            }
                            else if (entries[6] == "True")
                            {
                                
                                CreateAccount("Admin", entries[1], entries[2], entries[3], entries[4], entries[5], true);
                            }
                            success = true;
                        }
                    }
                }
            }
            return success;
        }
        // Check for correct number of entries, then if a staff account owns this assignment, then if the assignment already exists (in AddAssignment()).
        // Only then is an assignment added.
        // Text structure is: Staff Name,Assignment Name.
        public bool AcceptAssignmentsFromFile(string fileURL)
        {
            bool success = false;
            
            if(File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();

                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (entries.Count() == 3)
                    {
                        if (staffAccounts.ContainsKey(entries[0]))
                        {
                            staffAccounts[entries[0]].AddAssignment(new Assignment(entries[0], entries[1]));
                            success = true;
                        }
                    }
                }
            }
            return success;
        }

        // Check for correct number of entries, then if a student account is in the students accounts list. Only then is an assignment added.
        // Text structure is: StudentID,First Name,Last Name,Course.
        public bool AcceptStudentsFromFile(string fileURL)
        {
            bool success = false;
            if (File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();
                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (entries.Count() == 5)
                    {
                        if (!StudentAccounts.ContainsKey(entries[0]))
                        {
                            StudentAccounts.Add(entries[0], new Student(entries[0], entries[1], entries[2], entries[3]));
                            success = true;
                        }
                    }
                }
            }
            return success;
        }

        // Checks for the correct number of entries, then if the object for the student that submissed it exists, then if there is an assignment
        // in the staff objects that this submission is made to. If all is true then the submission is added to the submission list for that assignment.
        // Text structure is: Assignment name,Submission URL,Submission Name,Submission Date,Percentage Similarity,Student ID,Document Name.
        public bool AcceptSubmissionsFromFile(string fileURL)
        {
            bool success = false;
            if (File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();
                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (entries.Count() == 8)
                    {
                        if (StudentAccounts.Keys.Contains(entries[5]))
                        {
                            foreach (Staff staff in staffAccounts.Values)
                            {
                                if (staff.AssignmentLookup.ContainsKey(entries[0]))
                                {
                                    staff.AssignmentLookup[entries[0]].AddSubmission(new Submission(entries[1], entries[2], entries[3], entries[4],
                                                                                                    entries[5], entries[6]));
                                    success = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            return success;
        }

        public void SaveStaff(string fileURL)
        {
            List<string> appendDetails = new List<string>();
            List<string> appendCourses = new List<string>();
            List<string> appendModules = new List<string>();

            foreach (Staff staff in staffAccounts.Values)
            {
                foreach (string course in staff.CoursesTaught)
                {
                    appendCourses.Add(course + "=");
                }
                foreach (string module in staff.ModulesTaught)
                {
                    appendModules.Add(module + "-");
                }
                
                appendDetails.Add(staff.UserName + "," + staff.FirstName + "," + staff.LastName + "," + staff.Password + "," + staff.Email + "," + staff.SecretWord + "," + staff.IsAdmin.ToString() + ","
                                    + string.Join("", appendCourses) + string.Join("", appendModules));
                appendCourses.Clear();
                appendModules.Clear();
            }
            
            File.Create(fileURL).Dispose();
            File.AppendAllLines(fileURL, appendDetails);
        }

        public void SaveStudents(string fileURL)
        {
            List<string> appendDetails = new List<string>();
            foreach (Student student in StudentAccounts.Values)
            {
                appendDetails.Add(student.IdNumber + "," + student.FirstName + "," + student.LastName + "," + student.Course);
            }
            File.Create(fileURL).Dispose();
            File.AppendAllLines(fileURL, appendDetails);
            appendDetails.Clear();
        }

        public void SaveAssignments(string fileURL)
        {
            List<string> appendDetails = new List<string>();
            foreach (Staff staff in staffAccounts.Values)
            {
                foreach (Assignment assignment in staff.AssignmentLookup.Values)
                {
                    appendDetails.Add(assignment.StaffOwner + "," + assignment.AssignmentName);
                }
            }
            File.Create(fileURL).Dispose();
            File.AppendAllLines(fileURL, appendDetails);
            appendDetails.Clear();
        }

        public Staff GetLogin(string username, string password)
        {
            Staff result = null;

            if(staffAccounts.TryGetValue(username, out result))
            {
                // Check password is valid.
                if(result.Password != password)
                {
                    result = null;
                }
            }
            return result;
        }

        public List<String> GetStaffAccountNames()
        {
            return staffAccounts.Keys.ToList();
        }

        public bool updateAccount(Staff account)
        {
            bool success = false;
            if (staffAccounts.ContainsKey(account.UserName))
            {
                staffAccounts[account.UserName] = account;
                success = true;
            }
            return success;
        }

        public bool CreateAccount(string username, string firstName, string lastName, string password, string email, 
                                  string secretWord, bool isAdmin)
        {
            bool success = false;
            if(!this.staffAccounts.ContainsKey(username))
            {
                this.staffAccounts.Add(username, new Staff(username, firstName, lastName, password, email, secretWord, isAdmin));
                success = true;
            }
            return success;
        }

        public Staff GetAccount(string accountName)
        {
            if (this.staffAccounts.Keys.Contains(accountName))
            {
                return staffAccounts[accountName];
            }
            return null;
        }

        public Staff RecoverAccount(string email, string secretWord)
        {
            Staff account = null;
            accountList = staffAccounts.Values.ToList();
            int iterator = 0;
            int listSize = accountList.Count;
            while (iterator < listSize)
            {
                if (accountList[iterator].Email == email || accountList[iterator].SecretWord == secretWord)
                {
                    account = accountList[iterator];
                    iterator = listSize;
                }
                iterator++;
            }
            return account;
        }

        public bool DeleteAccount(string currentAccount)
        {
            bool success = false;
            if (this.staffAccounts.ContainsKey(currentAccount))
            {
                staffAccounts.Remove(currentAccount);
                success = true;
            }
            return success;
        }

        public bool HasEmail(string email)
        {
            bool success = false;
            foreach (Staff staff in staffAccounts.Values)
            {
                if (staff.Email == email)
                {
                    success = true;
                }
            }
            return success;
        }

        public bool AddCourseToStaff(string staffName, string courseName)
        {
            bool success = false;
            if (staffAccounts.ContainsKey(staffName))
            {
                if (!staffAccounts[staffName].CoursesTaught.Contains(courseName))
                {
                    staffAccounts[staffName].CoursesTaught.Add(courseName);
                    success = true;
                }
            }
            return success;
        }

        // Retrieve all of the submissions for a particular student that relate to the current staff member.
        public List<Submission> GetStudentSubmissions(string studentID, string staffUsername)
        {
            List<Submission> submissions = new List<Submission>();
            Staff staff = staffAccounts[staffUsername];
            foreach (Assignment assignment in staff.AssignmentLookup.Values)
            {
                foreach (Submission submission in assignment.AssignmentSubmissions)
                {
                    if (studentID == submission.StudentID)
                    {
                        submissions.Add(submission);
                    }
                }
            }
            return submissions;
        }
    }
}