﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DataModel
{
    public class DataManager
    {
        private static DataManager instance = null;

        // Set the location that the submissions are stored for future reference.
        private string submissionsFolderURL = Directory.GetCurrentDirectory().Replace(@"CheatInterface Test\bin\Debug", @"Submissions - DoNotDelete\");
        private Dictionary<string, Course> courseLookup = new Dictionary<string, Course>();
        private Dictionary<string, Module> moduleLookup = new Dictionary<string, Module>();
        private string moduleChosenForAssignments;

        public string SubmissionsFolderURL { get => submissionsFolderURL; set => submissionsFolderURL = value; }
        public Dictionary<string, Course> CourseLookup { get => courseLookup; }
        public Dictionary<string, Module> ModuleLookup { get => moduleLookup; }
        public string ModuleChosenForAssignments { get => moduleChosenForAssignments; set => moduleChosenForAssignments = value; }

        public static DataManager GetInstance()
        {
            if (instance == null)
            {
                instance = new DataManager();
            }
            return instance;
        }

        public Course GetCourse(string courseName)
        {
            Course result = null;
            if (this.CourseLookup.ContainsKey(courseName))
            {
                result = this.CourseLookup[courseName];
            }
            return result;
        }

        public bool AddCourse(Course newCourse)
        {
            bool success = false;
            if (!this.CourseLookup.ContainsKey(newCourse.CourseName))
            {
                CourseLookup.Add(newCourse.CourseName, newCourse);
                success = true;
            }
            return success;
        }

        public bool DeleteCourse(Course currentCourse)
        {
            bool success = false;
            if (this.CourseLookup.ContainsValue(currentCourse))
            {
                CourseLookup.Remove(currentCourse.CourseName);
                success = true;
            }
            return success;
        }

        public Module GetModule(string moduleName)
        {
            Module result = null;
            if (this.ModuleLookup.ContainsKey(moduleName))
            {
                result = this.ModuleLookup[moduleName];
            }
            return result;
        }

        public bool AddModule(Module newModule)
        {
            bool success = false;
            if (!this.ModuleLookup.ContainsKey(newModule.ModuleName))
            {
                ModuleLookup.Add(newModule.ModuleName, newModule);
                success = true;
            }
            return success;
        }

        public bool DeleteModule(Module currentModule)
        {
            bool success = false;
            if (this.ModuleLookup.ContainsValue(currentModule))
            {
                // Remove any instances of this module in all courses, them remove module.
                foreach (KeyValuePair<String, Course> course in CourseLookup)
                {
                    if (course.Value.CourseModuleNames.Contains(currentModule.ModuleName))
                    {
                        course.Value.CourseModuleNames.Remove(currentModule.ModuleName);
                    }
                }

                //modules also stored in accounts.

                ModuleLookup.Remove(currentModule.ModuleName);
                success = true;
            }
            return success;
        }

        // Checks if there is already a course with the same name and adds this one to the list if not. As the entries for courses are just
        // names error checking is not as vigorous compared to accepting submissions or assignments.
        // Text structure is: Course Name,Module Name/Module Name/Module Name. (Number of modules from zero and up).
        public bool AcceptCoursesFromFile(string fileURL)
        {
            bool success = false;
            if (File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();

                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (!CourseLookup.Keys.Contains(entries[0]))
                    {
                        CourseLookup.Add(entries[0], new Course(entries[0]));
                        if (entries.Count > 1)
                        {
                            if (entries[1].Replace(" ", "") != "")
                            {
                                List<string> moduleNames = entries[1].Split('-').ToList();
                                moduleNames.RemoveAt(moduleNames.Count-1);
                                CourseLookup[entries[0]].CourseModuleNames.AddRange(moduleNames);
                            }
                            success = true;
                        }
                    }
                }
            }
            return success;
        }

        // Checks if there is already a module with the same name and adds this one to the list if not. As the entries for modules are just
        // names error checking is not as vigorous compared to accepting submissions or assignments.
        // Text structure is: Module Name,Assignment Name-Assignment Name-Assignment Name-. (Number of assignments from zero and up).
        public bool AcceptModulesFromFile(string fileURL)
        {
            bool success = false;
            if (File.Exists(fileURL))
            {
                List<string> tryAccountsFromFile = File.ReadAllLines(fileURL).ToList();

                foreach (string line in tryAccountsFromFile)
                {
                    List<string> entries = line.Split(',').ToList();
                    if (!ModuleLookup.ContainsKey(entries[0]))
                    {
                        ModuleLookup.Add(entries[0], new Module(entries[0]));
                        if (entries.Count > 1)
                        {
                            if (entries[1].Replace(" ", "") != "")
                            {
                                List<string> assignmentNames = entries[1].Split('-').ToList();
                                ModuleLookup[entries[0]].ModuleAssignmentNames.AddRange(assignmentNames);
                                success = true;
                            }
                        }
                    }
                }
            }
            return success;
        }


        public void SaveCourses(string fileURL)
        {
            List<string> appendDetails = new List<string>();
            List<string> appendModules = new List<string>();
            foreach (Course course in courseLookup.Values)
            {
                foreach (string moduleName in course.CourseModuleNames)
                {
                    appendModules.Add(moduleName + "-");
                }
                appendDetails.Add(course.CourseName + "," + string.Join("", appendModules));
                appendModules.Clear();
            }
            File.Delete(fileURL);
            File.Create(fileURL).Dispose();
            File.AppendAllLines(fileURL, appendDetails);
        }

        public void SaveModules(string fileURL)
        {
            List<string> appendDetails = new List<string>();
            List<string> appendAssignments = new List<string>();
            foreach (Module module in moduleLookup.Values)
            {
                foreach (string assignmentName in module.ModuleAssignmentNames)
                {
                    appendAssignments.Add(assignmentName + "");
                }
                appendDetails.Add(module.ModuleName + "," + string.Join("-", appendAssignments));
            }
            File.Create(fileURL).Dispose();
            File.AppendAllLines(fileURL, appendDetails);
        }
    }
}