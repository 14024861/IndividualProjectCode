﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{

    public partial class UserControl_AssignmentView : UserControl
    {
        // Allowing access to functions in main class.
        PageManagement pageManagement = PageManagement.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        DataManager dataManager = DataManager.GetInstance();
        
        // Lists for main class to access controls for colour changes.
        private List<Label> labelList = new List<Label>();
        private List<Button> buttonList = new List<Button>();
        private List<Assignment> assignmentList = new List<Assignment>();

        private Button selectedAssignmentButton = null;
        private Button selectedSubmissionButton = null;

        // Colours used for dynamically created buttons, current colour scheme used is updated through PageManagement.
        Color buttonBackColour;
        Color buttonForeColour;

        public UserControl_AssignmentView()
        {
            InitializeComponent();

            // Adding all labels and buttons in user control and relevant panels into list for colour changes in pageManagement class.
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }
            foreach (FlowLayoutPanel pagePanel in this.Controls.OfType<FlowLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);

            // Clear lists after use as they are no longer needed.
            labelList.Clear();
            buttonList.Clear();

            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);
        }

        // Update the assignment list being looked through when accessing this page.
        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                assignmentList.Clear();
                selectedAssignmentButton = null;
                selectedSubmissionButton = null;
                flpSubmissions.Controls.Clear();
                flpAssignmentList.Controls.Clear();
                wbAssignmentViewer.Navigate("");
                btnShowStudentSubmissions.Text = "Select submission";

                if (dataManager.ModuleLookup.ContainsKey(dataManager.ModuleChosenForAssignments))
                {
                    // Check if assignments being viewed are both in the module and the assignments relevant to the current user.
                    foreach (string assignment in dataManager.ModuleLookup[dataManager.ModuleChosenForAssignments].ModuleAssignmentNames)
                    {
                        if (accountManager.accountLoggedIn.AssignmentLookup.ContainsKey(assignment))
                        {
                            assignmentList.Add(accountManager.accountLoggedIn.AssignmentLookup[assignment]);
                        }
                    }
                }

                if (assignmentList.Count == 0)
                {
                    btnFirstAssignment.Text = "No assignments";
                    btnSecondAssignment.Text = "No assignments";
                    btnFirstAssignment.Enabled = false;
                    btnSecondAssignment.Enabled = false;
                    btnShowMoreAssignments.Enabled = false;
                }
                else
                {
                    buttonBackColour = pageManagement.GetButtonBackColour();
                    buttonForeColour = pageManagement.GetButtonForeColour();

                    for (int i = 0; i < assignmentList.Count; i++)
                    {
                        if (i > 1)
                        {
                            flpAssignmentList.Controls.Add(CreateAssignmentButton("btn" + assignmentList[i].AssignmentName.Replace(" ", ""), i));
                            btnShowMoreAssignments.Enabled = true;
                        }
                        else if (i == 1)
                        {
                            btnSecondAssignment.Text = assignmentList[1].AssignmentName;
                            btnSecondAssignment.Enabled = true;
                        }
                        else
                        {
                            btnFirstAssignment.Text = assignmentList[0].AssignmentName;
                             
                            // Inform of there being only one assignment unless this is replaced in next loop.
                            btnSecondAssignment.Text = "No other assignments";
                            btnShowMoreAssignments.Enabled = false;
                            btnSecondAssignment.Enabled = false;
                            btnFirstAssignment.Enabled = true;
                        }
                    }
                }
                btnShowStudentSubmissions.Enabled = false;
            }
        }

        private Button CreateAssignmentButton(string buttonName, int assignmentPosition)
        {
            Button button = new Button();
            button.Name = buttonName;
            button.Width = 175;
            button.Height = 50;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;

            button.Click += (object sender, EventArgs e) =>
            {
                button.FlatStyle = FlatStyle.Standard;
                if (selectedAssignmentButton == null)
                {
                    selectedAssignmentButton = button;
                }
                else
                {
                    selectedAssignmentButton.FlatStyle = FlatStyle.Flat;
                    selectedAssignmentButton = button;
                }
                CreateSubmissionButtons(assignmentPosition, null);
            };
            return button;
        }

        private void CreateSubmissionButtons(int assignmentPosition, List<Submission> submissions)
        {
            List<Submission> submissionList = new List<Submission>();
            if (submissions == null)
            {
                submissionList = assignmentList[assignmentPosition].AssignmentSubmissions;
            }
            else
            {
                submissionList = submissions;
            }
            // Clear the current buttons in the panel list and add new ones relevant to the assignment submission related to the referenced assignment.
            flpSubmissions.Controls.Clear();
            foreach (Submission currentSub in submissionList)
            {
                Button button = new Button();
                button.Name = currentSub.StudentID + currentSub.DocumentName.Replace(" ", "");
                button.Text = currentSub.DocumentName + System.Environment.NewLine + currentSub.PercentageSimilarity + " | " + currentSub.StudentID + " | " + 
                              currentSub.SubmissionDate;
                button.Width = 175;
                button.Height = 50;
                button.BackColor = buttonBackColour;
                button.ForeColor = buttonForeColour;
                button.FlatStyle = FlatStyle.Flat;

                button.Click += (object sender, EventArgs e) =>
                {
                    if (currentSub.SubmissionURL != null)
                    {
                        button.FlatStyle = FlatStyle.Standard;
                        if (selectedSubmissionButton == null)
                        {
                            selectedSubmissionButton = button;
                        }
                        else
                        {
                            selectedSubmissionButton.FlatStyle = FlatStyle.Flat;
                            selectedSubmissionButton = button;
                        }
                        wbAssignmentViewer.Navigate(accountManager.SubmissionsFolderURL + currentSub.SubmissionURL);
                        btnShowStudentSubmissions.Text = "See all submissions from: " + currentSub.StudentID;
                        btnShowStudentSubmissions.Enabled = true;
                    }
                }; 
                flpSubmissions.Controls.Add(button);
            }
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("AssignmentView", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("AssignmentView", "UserHome");
            }
        }

        private void btnSelectAssignment_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AssignmentView", "SelectAssignment");
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AssignmentView", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("AssignmentView", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("AssignmentView", "UserHome");
            }
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("AssignmentView");
        }

        private void btnShowMoreAssignments_Click(object sender, EventArgs e)
        {
            if (flpAssignmentList.Visible == false)
            {
                flpAssignmentList.Visible = true;
            }
            else
            {
                flpAssignmentList.Visible = false;
            }
        }

        // First two buttons pre-made for selecting assignments.
        private void btnFirstAssignment_Click(object sender, EventArgs e)
        {
            if (assignmentList.Count > 0)
            {
                CreateSubmissionButtons(0, null);
            }
        }
        private void btnSecondAssignment_Click(object sender, EventArgs e)
        {
            if (assignmentList.Count > 1)
            {
                CreateSubmissionButtons(1, null);
            }
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("AssignmentView");
        }

        private void btnShowStudentSubmissions_Click(object sender, EventArgs e)
        {
            if (btnShowStudentSubmissions.Text != "Select submission")
            {
                List<string> buttonName = btnShowStudentSubmissions.Text.Split(':').ToList();
                string studentID = buttonName[1].Remove(0, 1);

                if (accountManager.StudentAccounts.ContainsKey(studentID))
                {
                    List<Submission> submissions = accountManager.GetStudentSubmissions(studentID, accountManager.accountLoggedIn.UserName);

                    flpSubmissions.Controls.Clear();
                    CreateSubmissionButtons(0, submissions);
                }
            }
        }
    }
}
