﻿namespace CheatInterface_Test
{
    partial class UserControl_AssignmentView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpSimilarSubmissions = new System.Windows.Forms.FlowLayoutPanel();
            this.flpSubmissions = new System.Windows.Forms.FlowLayoutPanel();
            this.lblSimilarSubmissions = new System.Windows.Forms.Label();
            this.lblAssignments = new System.Windows.Forms.Label();
            this.btnShowStudentSubmissions = new System.Windows.Forms.Button();
            this.btnShowMoreAssignments = new System.Windows.Forms.Button();
            this.btnSecondAssignment = new System.Windows.Forms.Button();
            this.btnFirstAssignment = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnSelectAssignment = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblAssignmentView = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.flpAssignmentList = new System.Windows.Forms.FlowLayoutPanel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.wbAssignmentViewer = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // flpSimilarSubmissions
            // 
            this.flpSimilarSubmissions.AutoScroll = true;
            this.flpSimilarSubmissions.BackColor = System.Drawing.Color.White;
            this.flpSimilarSubmissions.Location = new System.Drawing.Point(1071, 668);
            this.flpSimilarSubmissions.Name = "flpSimilarSubmissions";
            this.flpSimilarSubmissions.Size = new System.Drawing.Size(365, 363);
            this.flpSimilarSubmissions.TabIndex = 51;
            // 
            // flpSubmissions
            // 
            this.flpSubmissions.AutoScroll = true;
            this.flpSubmissions.BackColor = System.Drawing.Color.White;
            this.flpSubmissions.Location = new System.Drawing.Point(1075, 153);
            this.flpSubmissions.Name = "flpSubmissions";
            this.flpSubmissions.Size = new System.Drawing.Size(361, 471);
            this.flpSubmissions.TabIndex = 50;
            // 
            // lblSimilarSubmissions
            // 
            this.lblSimilarSubmissions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblSimilarSubmissions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSimilarSubmissions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSimilarSubmissions.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSimilarSubmissions.Location = new System.Drawing.Point(1071, 627);
            this.lblSimilarSubmissions.Name = "lblSimilarSubmissions";
            this.lblSimilarSubmissions.Size = new System.Drawing.Size(365, 34);
            this.lblSimilarSubmissions.TabIndex = 49;
            this.lblSimilarSubmissions.Text = "Similar Submissions            ";
            // 
            // lblAssignments
            // 
            this.lblAssignments.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblAssignments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAssignments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAssignments.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignments.Location = new System.Drawing.Point(1074, 112);
            this.lblAssignments.Name = "lblAssignments";
            this.lblAssignments.Size = new System.Drawing.Size(361, 34);
            this.lblAssignments.TabIndex = 48;
            this.lblAssignments.Text = "Submissions                        ";
            // 
            // btnShowStudentSubmissions
            // 
            this.btnShowStudentSubmissions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowStudentSubmissions.Location = new System.Drawing.Point(821, 112);
            this.btnShowStudentSubmissions.Name = "btnShowStudentSubmissions";
            this.btnShowStudentSubmissions.Size = new System.Drawing.Size(244, 75);
            this.btnShowStudentSubmissions.TabIndex = 47;
            this.btnShowStudentSubmissions.Text = "_";
            this.btnShowStudentSubmissions.UseVisualStyleBackColor = true;
            this.btnShowStudentSubmissions.Click += new System.EventHandler(this.btnShowStudentSubmissions_Click);
            // 
            // btnShowMoreAssignments
            // 
            this.btnShowMoreAssignments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowMoreAssignments.Font = new System.Drawing.Font("Wingdings 3", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnShowMoreAssignments.Location = new System.Drawing.Point(739, 112);
            this.btnShowMoreAssignments.Name = "btnShowMoreAssignments";
            this.btnShowMoreAssignments.Size = new System.Drawing.Size(75, 75);
            this.btnShowMoreAssignments.TabIndex = 46;
            this.btnShowMoreAssignments.Text = "q";
            this.btnShowMoreAssignments.UseVisualStyleBackColor = true;
            this.btnShowMoreAssignments.Click += new System.EventHandler(this.btnShowMoreAssignments_Click);
            // 
            // btnSecondAssignment
            // 
            this.btnSecondAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecondAssignment.Location = new System.Drawing.Point(371, 112);
            this.btnSecondAssignment.Name = "btnSecondAssignment";
            this.btnSecondAssignment.Size = new System.Drawing.Size(362, 75);
            this.btnSecondAssignment.TabIndex = 45;
            this.btnSecondAssignment.Text = "No other assignments";
            this.btnSecondAssignment.UseVisualStyleBackColor = true;
            this.btnSecondAssignment.Click += new System.EventHandler(this.btnSecondAssignment_Click);
            // 
            // btnFirstAssignment
            // 
            this.btnFirstAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFirstAssignment.Location = new System.Drawing.Point(3, 112);
            this.btnFirstAssignment.Name = "btnFirstAssignment";
            this.btnFirstAssignment.Size = new System.Drawing.Size(362, 75);
            this.btnFirstAssignment.TabIndex = 44;
            this.btnFirstAssignment.Text = "No assignment";
            this.btnFirstAssignment.UseVisualStyleBackColor = true;
            this.btnFirstAssignment.Click += new System.EventHandler(this.btnFirstAssignment_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 43;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 42;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnSelectAssignment
            // 
            this.btnSelectAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectAssignment.Location = new System.Drawing.Point(959, 3);
            this.btnSelectAssignment.Name = "btnSelectAssignment";
            this.btnSelectAssignment.Size = new System.Drawing.Size(160, 49);
            this.btnSelectAssignment.TabIndex = 41;
            this.btnSelectAssignment.Text = "Select Assignment";
            this.btnSelectAssignment.UseVisualStyleBackColor = true;
            this.btnSelectAssignment.Click += new System.EventHandler(this.btnSelectAssignment_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 40;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblAssignmentView
            // 
            this.lblAssignmentView.AutoSize = true;
            this.lblAssignmentView.BackColor = System.Drawing.Color.Transparent;
            this.lblAssignmentView.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignmentView.Location = new System.Drawing.Point(195, 9);
            this.lblAssignmentView.Name = "lblAssignmentView";
            this.lblAssignmentView.Size = new System.Drawing.Size(278, 37);
            this.lblAssignmentView.TabIndex = 39;
            this.lblAssignmentView.Text = "Assignment View";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 37;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 38;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1276, 34);
            this.lblPageAdvice.TabIndex = 64;
            this.lblPageAdvice.Text = "To view more assignments select the triangle button below.";
            // 
            // flpAssignmentList
            // 
            this.flpAssignmentList.AutoScroll = true;
            this.flpAssignmentList.BackColor = System.Drawing.Color.White;
            this.flpAssignmentList.Location = new System.Drawing.Point(672, 191);
            this.flpAssignmentList.Name = "flpAssignmentList";
            this.flpAssignmentList.Size = new System.Drawing.Size(361, 470);
            this.flpAssignmentList.TabIndex = 75;
            this.flpAssignmentList.Visible = false;
            // 
            // wbAssignmentViewer
            // 
            this.wbAssignmentViewer.Location = new System.Drawing.Point(4, 193);
            this.wbAssignmentViewer.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbAssignmentViewer.Name = "wbAssignmentViewer";
            this.wbAssignmentViewer.Size = new System.Drawing.Size(1061, 837);
            this.wbAssignmentViewer.TabIndex = 76;
            // 
            // UserControl_AssignmentView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flpAssignmentList);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.flpSimilarSubmissions);
            this.Controls.Add(this.flpSubmissions);
            this.Controls.Add(this.lblSimilarSubmissions);
            this.Controls.Add(this.lblAssignments);
            this.Controls.Add(this.btnShowStudentSubmissions);
            this.Controls.Add(this.btnShowMoreAssignments);
            this.Controls.Add(this.btnSecondAssignment);
            this.Controls.Add(this.btnFirstAssignment);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnSelectAssignment);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblAssignmentView);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Controls.Add(this.wbAssignmentViewer);
            this.Name = "UserControl_AssignmentView";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpSimilarSubmissions;
        private System.Windows.Forms.FlowLayoutPanel flpSubmissions;
        private System.Windows.Forms.Label lblSimilarSubmissions;
        private System.Windows.Forms.Label lblAssignments;
        private System.Windows.Forms.Button btnShowStudentSubmissions;
        private System.Windows.Forms.Button btnShowMoreAssignments;
        private System.Windows.Forms.Button btnSecondAssignment;
        private System.Windows.Forms.Button btnFirstAssignment;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnSelectAssignment;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblAssignmentView;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.FlowLayoutPanel flpAssignmentList;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.WebBrowser wbAssignmentViewer;
    }
}
