﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using DataModel;


namespace CheatInterface_Test
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            PageManagement pageManagement = PageManagement.GetInstance();
            AccountManager accountManager = AccountManager.GetInstance();
            DataManager dataManager = DataManager.GetInstance();

            // Uses dictionary with generic names for keys so that user controls do not need the actual name of other 
            // user controls to reference them, makes it easier to interchange new controls for the same page.
            pageManagement.AddToPageList("AdminHome", userControl_AdminHomePage1);
            pageManagement.AddToPageList("AllocateAssignments", userControl_AllocateAssignments1);
            pageManagement.AddToPageList("AssignmentView", userControl_AssignmentView1);
            pageManagement.AddToPageList("Login", userControlLogin1);
            pageManagement.AddToPageList("SelectAssignment", userControl_SelectAssignment1);
            pageManagement.AddToPageList("Settings", userControl_Settings1);
            pageManagement.AddToPageList("UserHome", userControl_UserHomePage1);
            pageManagement.AddToPageList("CreateAccount", userControl_CreateAccount2);
            pageManagement.AddToPageList("ModuleManagement", userControlModuleManagement1);
            pageManagement.AddToPageList("CourseManagement", userControl_CourseManagement1);
            
            // Adding first page viewed to list of pages viewed for forward and back buttons to work correctly.
            pageManagement.AddToPageHistoryList(userControlLogin1);
            pageManagement.ChangeTheme("normal");

            // Set to false to trigger event handler when first visiting pages.
            userControl_Settings1.Visible = false;
            userControl_UserHomePage1.Visible = false;
            userControl_AssignmentView1.Visible = false;
            userControlModuleManagement1.Visible = false;
            userControl_CourseManagement1.Visible = false;
            userControl_CreateAccount2.Visible = false;
            userControl_AllocateAssignments1.Visible = false;
            userControl_SelectAssignment1.Visible = false;

            // The order that these functions are called in matter as data for submissions is fed into current assignments etc.
            string folderURL = accountManager.SubmissionsFolderURL;
            accountManager.AcceptStaffFromFile(folderURL + "staff.txt");
            accountManager.AcceptStudentsFromFile(folderURL + "students.txt");
            dataManager.AcceptCoursesFromFile(folderURL + "courses.txt");
            dataManager.AcceptModulesFromFile(folderURL + "modules.txt");
            accountManager.AcceptAssignmentsFromFile(folderURL + "assignments.txt");
            accountManager.AcceptSubmissionsFromFile(folderURL + "submissions.txt");
        }
    }
}
