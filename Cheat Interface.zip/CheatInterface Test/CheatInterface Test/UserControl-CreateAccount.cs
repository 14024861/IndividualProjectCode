﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_CreateAccount : UserControl
    {
        AccountManager accountManager = AccountManager.GetInstance();
        PageManagement pageManagement = PageManagement.GetInstance();
        private List<Label> labelList = new List<Label>();
        private List<Button> buttonList = new List<Button>();
        private List<RadioButton> radioButtonList = new List<RadioButton>();
        private List<TextBox> textBoxList = new List<TextBox>();
        private List<Label> labelAccountDetailsList = new List<Label>();
        private List<string> accountNames = new List<string>();
        private Color buttonBackColour;
        private Color buttonForeColour;

        public UserControl_CreateAccount()
        {
            InitializeComponent();

            // Adding all labels and buttons in user control and relevant panels into list for colour changes in pageManagement class.
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }
            foreach (TableLayoutPanel pagePanel in this.Controls.OfType<TableLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);

                    // Add labels that are responsible for showing user details to list for clearing the text when accessing this page.
                    if (panelLabel.Name.Contains("Text"))
                    {
                        labelAccountDetailsList.Add(panelLabel);
                    }
                }
                foreach (TextBox textbox in pagePanel.Controls.OfType<TextBox>())
                {
                    textBoxList.Add(textbox);
                }
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);
            pageManagement.AddToPageRadioButtons(radioButtonList);
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                Color back = pageManagement.GetButtonBackColour();
                Color front = pageManagement.GetButtonForeColour();
                List<string> staffAccountNames = accountManager.GetStaffAccountNames();

                ResetControls();
                accountNames.Clear();
                flpAccountList.Controls.Clear();
                accountNames.AddRange(accountManager.GetStaffAccountNames());

                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                foreach (string accountName in accountNames)
                {
                    flpAccountList.Controls.Add(CreateAccountButton(accountName));
                }

                foreach (TextBox textbox in textBoxList)
                {
                    textbox.Clear();
                }

                foreach (Label label in labelAccountDetailsList)
                {
                    label.Text = "_";
                }

                foreach (FlowLayoutPanel panel in this.Controls.OfType<FlowLayoutPanel>())
                {
                    // Buttons made dynamically on this page are not added the the button list in PageManagement to avoid needing
                    // to call for the whole button list to remove them (given its size), colours are changed here instead.
                    foreach (Button button in panel.Controls.OfType<Button>())
                    {
                        button.BackColor = back;
                        button.ForeColor = front;
                    }
                }
                btnAllocateModules.Enabled = false;
                btnCreate.Enabled = false;
                btnDeleteAccount.Enabled = false;
            }
        }

        // Create a new account if the appropriate fields are filled correctly, and make a button for showing this account's
        // details and deleting it.
        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (!(tbEmail.Text.Contains("@") && (tbEmail.Text.Contains("."))))
            {
                lblMessageBadInput.Text = "Please make sure the Email address has the proper format.";
            }
            else if (accountManager.HasEmail(tbEmail.Text))
            {
                lblMessageBadInput.Text = "Sorry that email has been taken. Please try a new email.";
            }
            else if (accountManager.CreateAccount(tbUsername.Text, tbFirstName.Text, tbLastName.Text, tbPassword.Text, tbEmail.Text,
                tbSecretWord.Text, false))
            {
                // The button needs to be made in a seperate function to allow the 'button.Click += (object sender, EventArgs e) =>'
                // lambda function to be used in this case.
                flpAccountList.Controls.Add(CreateAccountButton(tbUsername.Text));
                ResetControls();
            }
            else
            {
                lblMessageBadInput.Text = "Failed to add the new account. is the username unique?";
            }
        }
           
        
        

        // Create a new button to add to the right hand panel for viewing the account's details and deleting it.
        private Button CreateAccountButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName;
            button.Text = buttonName;
            button.BackColor = pageManagement.GetButtonBackColour();
            button.ForeColor = pageManagement.GetButtonForeColour();
            button.FlatStyle = FlatStyle.Flat;
            button.Height = 50;
            button.Width = 150;

            //https://stackoverflow.com/questions/6187944/how-can-i-create-a-dynamic-button-click-event-on-a-dynamic-button
            // Uses lambda function for implicit event handler, when clicked the submissions for this particular assignment are listed by a different function
            button.Click += (object sender, EventArgs e) =>
            {
                Staff currentStaff = accountManager.GetAccount(buttonName);
                lblSelectedUserUsernameText.Text = currentStaff.UserName;
                lblSelectedUserFirstNameText.Text = currentStaff.FirstName;
                lblSelectedUserLastNameText.Text = currentStaff.LastName;
                lblSelectedUserPasswordText.Text = currentStaff.Password;
                lblSelectedUserEmailText.Text = currentStaff.Email;
                lblSelectedUserSecretWordText.Text = currentStaff.SecretWord;

                if (currentStaff.IsAdmin == true)
                {
                    lblSelectedUserAccountTypeText.Text = "Admin";
                }
                else
                {
                    lblSelectedUserAccountTypeText.Text = "Standard";
                }
                btnAllocateModules.Enabled = true;
                btnDeleteAccount.Enabled = true;
            };
            return button;
        }

        private void btnDeleteAccount_Click(object sender, EventArgs e)
        {
            if (lblSelectedUserAccountTypeText.Text != "Admin")
            {
                if (accountManager.DeleteAccount(lblSelectedUserUsernameText.Text))
                {
                    flpAccountList.Controls.Remove(flpAccountList.Controls.Find(lblSelectedUserUsernameText.Text, false)[0]);
                    ResetControls();
                }
            }
            else
            {
                lblMessageCantWithAdmin.Text = "Cannot delete an Admin account.";
            }
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("CreateAccount");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("CreateAccount");
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("CreateAccount", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("CreateAccount", "UserHome");
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CreateAccount", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("CreateAccount", "Login");
        }

        private void ResetControls()
        {
            lblMessageBadInput.Text = "";
            lblMessageCantWithAdmin.Text = "";
        }

        private void btnModuleManagement_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CreateAccount", "ModuleManagement");
        }

        private void btnAllocateModules_Click(object sender, EventArgs e)
        {
            if (lblSelectedUserAccountTypeText.Text != "Admin")
            {
                accountManager.accountSelected = accountManager.GetAccount(lblSelectedUserUsernameText.Text);
                pageManagement.ChangePage("CreateAccount", "AllocateAssignments");
            }
            else
            {
                lblMessageCantWithAdmin.Text = "Cannot add modules to an Admin account.";
            }
                
        }

        private void btnManageCourses_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CreateAccount", "CourseManagement");
        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" &&
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }

        private void tbFirstName_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" &&
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }

        private void tbLastName_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" &&
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" &&
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }

        private void tbEmail_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" && 
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }

        private void tbSecretWord_TextChanged(object sender, EventArgs e)
        {
            if (tbUsername.Text.Replace(" ", "") != "" && tbFirstName.Text.Replace(" ", "") != "" && tbLastName.Text.Replace(" ", "") != "" && tbPassword.Text.Replace(" ", "") != "" &&
                tbEmail.Text.Replace(" ", "") != "" && tbSecretWord.Text.Replace(" ", "") != "")
            {
                btnCreate.Enabled = true;
            }
            else
            {
                btnCreate.Enabled = false;
            }
        }
    }
}

