﻿namespace CheatInterface_Test
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.userControlLogin1 = new CheatInterface_Test.UserControlLogin();
            this.userControl_UserHomePage1 = new CheatInterface_Test.UserControl_UserHomePage();
            this.userControl_Settings1 = new CheatInterface_Test.UserControl_Settings();
            this.userControl_SelectAssignment1 = new CheatInterface_Test.UserControl_SelectAssignment();
            this.userControl_AssignmentView1 = new CheatInterface_Test.UserControl_AssignmentView();
            this.userControl_AllocateAssignments1 = new CheatInterface_Test.UserControl_AllocateAssignments();
            this.userControl_AdminHomePage1 = new CheatInterface_Test.UserControl_AdminHomePage();
            this.userControlModuleManagement1 = new CheatInterface_Test.ModuleManagement();
            this.userControl_CreateAccount2 = new CheatInterface_Test.UserControl_CreateAccount();
            this.userControl_CourseManagement1 = new CheatInterface_Test.UserControl_CourseManagement();
            this.SuspendLayout();
            // 
            // userControlLogin1
            // 
            this.userControlLogin1.BackColor = System.Drawing.Color.Transparent;
            this.userControlLogin1.Location = new System.Drawing.Point(0, 0);
            this.userControlLogin1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.userControlLogin1.Name = "userControlLogin1";
            this.userControlLogin1.Size = new System.Drawing.Size(1450, 1050);
            this.userControlLogin1.TabIndex = 6;
            // 
            // userControl_UserHomePage1
            // 
            this.userControl_UserHomePage1.BackColor = System.Drawing.Color.Transparent;
            this.userControl_UserHomePage1.Location = new System.Drawing.Point(0, 0);
            this.userControl_UserHomePage1.Name = "userControl_UserHomePage1";
            this.userControl_UserHomePage1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_UserHomePage1.TabIndex = 5;
            // 
            // userControl_Settings1
            // 
            this.userControl_Settings1.BackColor = System.Drawing.Color.Transparent;
            this.userControl_Settings1.Location = new System.Drawing.Point(0, 0);
            this.userControl_Settings1.Name = "userControl_Settings1";
            this.userControl_Settings1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_Settings1.TabIndex = 4;
            // 
            // userControl_SelectAssignment1
            // 
            this.userControl_SelectAssignment1.Location = new System.Drawing.Point(0, 0);
            this.userControl_SelectAssignment1.Name = "userControl_SelectAssignment1";
            this.userControl_SelectAssignment1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_SelectAssignment1.TabIndex = 3;
            // 
            // userControl_AssignmentView1
            // 
            this.userControl_AssignmentView1.Location = new System.Drawing.Point(0, 0);
            this.userControl_AssignmentView1.Name = "userControl_AssignmentView1";
            this.userControl_AssignmentView1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_AssignmentView1.TabIndex = 2;
            // 
            // userControl_AllocateAssignments1
            // 
            this.userControl_AllocateAssignments1.Location = new System.Drawing.Point(0, 0);
            this.userControl_AllocateAssignments1.Name = "userControl_AllocateAssignments1";
            this.userControl_AllocateAssignments1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_AllocateAssignments1.TabIndex = 1;
            // 
            // userControl_AdminHomePage1
            // 
            this.userControl_AdminHomePage1.BackColor = System.Drawing.Color.Transparent;
            this.userControl_AdminHomePage1.Location = new System.Drawing.Point(0, 0);
            this.userControl_AdminHomePage1.Name = "userControl_AdminHomePage1";
            this.userControl_AdminHomePage1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_AdminHomePage1.TabIndex = 0;
            // 
            // userControlModuleManagement1
            // 
            this.userControlModuleManagement1.Location = new System.Drawing.Point(0, 0);
            this.userControlModuleManagement1.Name = "userControlModuleManagement1";
            this.userControlModuleManagement1.Size = new System.Drawing.Size(1450, 1050);
            this.userControlModuleManagement1.TabIndex = 9;
            // 
            // userControl_CreateAccount2
            // 
            this.userControl_CreateAccount2.Location = new System.Drawing.Point(0, 0);
            this.userControl_CreateAccount2.Name = "userControl_CreateAccount2";
            this.userControl_CreateAccount2.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_CreateAccount2.TabIndex = 10;
            // 
            // userControl_CourseManagement1
            // 
            this.userControl_CourseManagement1.Location = new System.Drawing.Point(0, 0);
            this.userControl_CourseManagement1.Name = "userControl_CourseManagement1";
            this.userControl_CourseManagement1.Size = new System.Drawing.Size(1450, 1050);
            this.userControl_CourseManagement1.TabIndex = 11;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1458, 1054);
            this.Controls.Add(this.userControlLogin1);
            this.Controls.Add(this.userControl_UserHomePage1);
            this.Controls.Add(this.userControl_Settings1);
            this.Controls.Add(this.userControl_SelectAssignment1);
            this.Controls.Add(this.userControl_AssignmentView1);
            this.Controls.Add(this.userControl_AllocateAssignments1);
            this.Controls.Add(this.userControl_AdminHomePage1);
            this.Controls.Add(this.userControl_CourseManagement1);
            this.Controls.Add(this.userControlModuleManagement1);
            this.Controls.Add(this.userControl_CreateAccount2);
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private UserControl_AdminHomePage userControl_AdminHomePage1;
        private UserControl_AllocateAssignments userControl_AllocateAssignments1;
        private UserControl_AssignmentView userControl_AssignmentView1;
        private UserControl_SelectAssignment userControl_SelectAssignment1;
        private UserControl_Settings userControl_Settings1;
        private UserControl_UserHomePage userControl_UserHomePage1;
        private UserControlLogin userControlLogin1;
        private ModuleManagement userControlModuleManagement1;
        private UserControl_CreateAccount userControl_CreateAccount2;
        private UserControl_CourseManagement userControl_CourseManagement1;
    }
}