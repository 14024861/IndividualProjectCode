﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_AllocateAssignments : UserControl
    {
        // Allowing access to functions in main class
        PageManagement pageManagement = PageManagement.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        DataManager dataManager = DataManager.GetInstance();

        // Lists for main class to access controls for colour changes
        private List<Label> labelList = new List<Label>();
        private List<Button> buttonList = new List<Button>();
        private List<string> buttonNameAddToAccountList = new List<string>();
        private List<string> buttonNameRemovalList = new List<string>();
        Button selectedCourseButton = null;
        Button selectedModuleButton = null;

        Color buttonBackColour;
        Color buttonForeColour;

        public UserControl_AllocateAssignments()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            foreach (FlowLayoutPanel pagePanel in this.Controls.OfType<FlowLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);

            // Clear lists after use as they are no longer needed
            labelList.Clear();
            buttonList.Clear();
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                selectedCourseButton = null;
                selectedModuleButton = null;

                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                buttonNameAddToAccountList.Clear();
                buttonNameRemovalList.Clear();
                flpCourses.Controls.Clear();
                flpModules.Controls.Clear();
                flpSelectedModules.Controls.Clear();
                flpModulesInAccount.Controls.Clear();

                foreach (string course in dataManager.CourseLookup.Keys)
                {
                    flpCourses.Controls.Add(CreateCourseButton(course));
                }
                if (dataManager.CourseLookup.Count > 0)
                {
                    string firstCourse = dataManager.CourseLookup.Keys.First();
                    foreach (string moduleName in dataManager.CourseLookup[firstCourse].CourseModuleNames)
                    {
                        flpModules.Controls.Add(CreateModuleButton(firstCourse + " | " + moduleName));
                    }
                }
                if (accountManager.accountSelected != null)
                {
                    foreach (string moduleName in accountManager.accountSelected.ModulesTaught)
                    {
                        flpModulesInAccount.Controls.Add(CreateRemovalButton(moduleName));
                    }
                }
            }
        }

        private Button CreateCourseButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Height = 50;
            button.Width = 175;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                selectedModuleButton = null;
                flpModules.Controls.Clear();
                button.FlatStyle = FlatStyle.Standard;
                if (selectedCourseButton == null)
                {
                    selectedCourseButton = button;
                }
                else
                {
                    selectedCourseButton.FlatStyle = FlatStyle.Flat;
                    selectedCourseButton = button;
                }
                foreach (string moduleName in dataManager.CourseLookup[buttonName].CourseModuleNames)
                {
                    flpModules.Controls.Add(CreateModuleButton(button.Name + " | " + moduleName));
                }
            };
            return button;
        }

        private Button CreateModuleButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Height = 50;
            button.Width = 175;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                if (!(flpSelectedModules.Controls.Find(button.Name, false).Count() > 0))
                {
                    flpSelectedModules.Controls.Add(CreateTempButton(button.Text));
                    buttonNameAddToAccountList.Add(button.Text);
                }
            };
            return button;
        }

        private Button CreateTempButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Height = 50;
            button.Width = 175;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                flpSelectedModules.Controls.Remove(button);
                buttonNameAddToAccountList.Remove(button.Text);
            };
            return button;
        }
        private Button CreateRemovalButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Height = 50;
            button.Width = 175;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                
                if (button.FlatStyle == FlatStyle.Flat)
                {
                    button.FlatStyle = FlatStyle.Standard;
                    buttonNameRemovalList.Add(button.Text);
                }
                else
                {
                    selectedModuleButton.FlatStyle = FlatStyle.Flat;
                    buttonNameRemovalList.Remove(button.Text);
                }
            };
            return button;
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("AllocateAssignments", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("AllocateAssignments", "UserHome");
            }
        }

        private void btnSelectAssignment_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AllocateAssignments", "SelectAssignment");
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AllocateAssignments", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("AllocateAssignments", "Login");
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (accountManager.accountSelected != null)
            {
                foreach (string moduleName in buttonNameAddToAccountList)
                {
                    List<string> courseAndModule = moduleName.Split('|').ToList<string>();
                    courseAndModule[0] = courseAndModule[0].Remove(courseAndModule[0].Length - 1, 1);
                    courseAndModule[1] = courseAndModule[1].Remove(0, 1);

                    if (!accountManager.accountSelected.ModulesTaught.Contains(courseAndModule[1]))
                    {
                        accountManager.accountSelected.ModulesTaught.Add(courseAndModule[1]);
                    }
                    if (!accountManager.accountSelected.CoursesTaught.Contains(courseAndModule[0]))
                    {
                        accountManager.accountSelected.CoursesTaught.Add(courseAndModule[0]);
                    }
                }
                foreach (string moduleName in buttonNameRemovalList)
                {
                    if (accountManager.accountSelected.ModulesTaught.Contains(moduleName))
                    {
                        accountManager.accountSelected.ModulesTaught.Remove(moduleName);
                    }
                }
            }
            pageManagement.ChangePage("AllocateAssignments", "CreateAccount");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("AllocateAssignments");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("AllocateAssignments");
        }

        private void btnModuleManagement_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AllocateAssignments", "ModuleManagement");
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AllocateAssignments", "CreateAccount");
        }
    }

}
