﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControlLogin : UserControl
    {
        // Allowing access to functions in main class
        PageManagement pageManagement = PageManagement.GetInstance();
        DataManager dataManager = DataManager.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        // Lists for main class to access controls for colour changes
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();
        
        Staff user = null;
        private string username = string.Empty;
        private string password = string.Empty;

        public UserControlLogin()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            foreach (Panel pagePanel in this.Controls.OfType<Panel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);

            // Clear lists after use as they are no longer needed
            labelList.Clear();
            buttonList.Clear();
            btnLogIn.Enabled = false;
            btnContinue.Enabled = false;
        }

        private void UserControlLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            if (!pnlForgotPassword.Visible)
            {
                pnlForgotPassword.Show();
            }
            else
            {
                pnlForgotPassword.Hide();
            }
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            user = accountManager.GetLogin(tbUsername.Text, tbPassword.Text);

            if (user == null)
            {
                lblIncorrectLoginMessage.Visible = true;
            }
            else
            {
                accountManager.accountLoggedIn = user;

                if (user.IsAdmin)
                {
                    pageManagement.ChangePage("Login", "AdminHome");
                }
                else
                {
                    pageManagement.ChangePage("Login", "UserHome");
                }
            }

        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("Login");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("Login");
        }

        // Gives the user's username and password if they have forgotten it by using email and secret word.
        private void btnContinue_Click(object sender, EventArgs e)
        {
            user = accountManager.RecoverAccount(tbEmail.Text, tbSecretWord.Text);
            if (user == null)
            {
                lblIncorrectLoginMessage.Text = "Email and secret word combonation not recognised.";
            }
            else
            {
                user.Password = "reset";
                accountManager.updateAccount(user);
                MessageBox.Show("Username is " + user.UserName + ". Password has been changed to 'reset'");
            }
        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {
            if (tbPassword.Text != "" && tbUsername.Text != "")
            {
                btnContinue.Enabled = true;
            }
            else
            {
                btnContinue.Enabled = false;
            }
        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {
            if (tbPassword.Text != "" && tbUsername.Text != "")
            {
                btnLogIn.Enabled = true;
            }
            else
            {
                btnLogIn.Enabled = false;
            }
        }

        private void tbEmail_TextChanged(object sender, EventArgs e)
        {
            if (tbEmail.Text != "" && tbSecretWord.Text != "")
            {
                btnContinue.Enabled = true;
            }
            else
            {
                btnContinue.Enabled = false;
            }
        }

        private void tbSecretWord_TextChanged(object sender, EventArgs e)
        {
            if (tbEmail.Text != "" && tbSecretWord.Text != "")
            {
                btnContinue.Enabled = true;
            }
            else
            {
                btnContinue.Enabled = false;
            }
        }
    }
}
