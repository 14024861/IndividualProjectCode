﻿namespace CheatInterface_Test
{
    partial class UserControl_UserHomePage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpTopSimilarities = new System.Windows.Forms.FlowLayoutPanel();
            this.flpDueAssignments = new System.Windows.Forms.FlowLayoutPanel();
            this.lblTopSimilarities = new System.Windows.Forms.Label();
            this.lblRecentDueAssignments = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnSelectAssignment = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // flpTopSimilarities
            // 
            this.flpTopSimilarities.BackColor = System.Drawing.Color.White;
            this.flpTopSimilarities.Location = new System.Drawing.Point(3, 542);
            this.flpTopSimilarities.Name = "flpTopSimilarities";
            this.flpTopSimilarities.Size = new System.Drawing.Size(430, 354);
            this.flpTopSimilarities.TabIndex = 26;
            // 
            // flpDueAssignments
            // 
            this.flpDueAssignments.BackColor = System.Drawing.Color.White;
            this.flpDueAssignments.Location = new System.Drawing.Point(3, 148);
            this.flpDueAssignments.Name = "flpDueAssignments";
            this.flpDueAssignments.Size = new System.Drawing.Size(430, 354);
            this.flpDueAssignments.TabIndex = 25;
            // 
            // lblTopSimilarities
            // 
            this.lblTopSimilarities.AutoSize = true;
            this.lblTopSimilarities.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTopSimilarities.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopSimilarities.Location = new System.Drawing.Point(3, 505);
            this.lblTopSimilarities.Name = "lblTopSimilarities";
            this.lblTopSimilarities.Size = new System.Drawing.Size(430, 34);
            this.lblTopSimilarities.TabIndex = 24;
            this.lblTopSimilarities.Text = "Top Similarities                               ";
            // 
            // lblRecentDueAssignments
            // 
            this.lblRecentDueAssignments.AutoSize = true;
            this.lblRecentDueAssignments.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRecentDueAssignments.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecentDueAssignments.Location = new System.Drawing.Point(3, 111);
            this.lblRecentDueAssignments.Name = "lblRecentDueAssignments";
            this.lblRecentDueAssignments.Size = new System.Drawing.Size(434, 34);
            this.lblRecentDueAssignments.TabIndex = 23;
            this.lblRecentDueAssignments.Text = "Recent Due Assignments              ";
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 22;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 21;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnSelectAssignment
            // 
            this.btnSelectAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSelectAssignment.Location = new System.Drawing.Point(959, 3);
            this.btnSelectAssignment.Name = "btnSelectAssignment";
            this.btnSelectAssignment.Size = new System.Drawing.Size(160, 49);
            this.btnSelectAssignment.TabIndex = 20;
            this.btnSelectAssignment.Text = "Select Assignment";
            this.btnSelectAssignment.UseVisualStyleBackColor = true;
            this.btnSelectAssignment.Click += new System.EventHandler(this.btnSelectAssignment_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(194, 37);
            this.lblPageName.TabIndex = 18;
            this.lblPageName.Text = "Home Page";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 16;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 17;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.AutoSize = true;
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(165, 34);
            this.lblPageAdvice.TabIndex = 42;
            this.lblPageAdvice.Text = "Welcome _.";
            // 
            // UserControl_UserHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.flpTopSimilarities);
            this.Controls.Add(this.flpDueAssignments);
            this.Controls.Add(this.lblTopSimilarities);
            this.Controls.Add(this.lblRecentDueAssignments);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnSelectAssignment);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_UserHomePage";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpTopSimilarities;
        private System.Windows.Forms.FlowLayoutPanel flpDueAssignments;
        private System.Windows.Forms.Label lblTopSimilarities;
        private System.Windows.Forms.Label lblRecentDueAssignments;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnSelectAssignment;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Label lblPageAdvice;
    }
}
