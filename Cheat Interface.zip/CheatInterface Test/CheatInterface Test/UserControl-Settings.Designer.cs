﻿namespace CheatInterface_Test
{
    partial class UserControl_Settings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLayout = new System.Windows.Forms.Label();
            this.btnEditSecretWord = new System.Windows.Forms.Button();
            this.btnEditPassword = new System.Windows.Forms.Button();
            this.tlpField = new System.Windows.Forms.TableLayoutPanel();
            this.lblSecretWord = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblPasswordMessage = new System.Windows.Forms.Label();
            this.lblSecretWordMessage = new System.Windows.Forms.Label();
            this.lblFirstNameText = new System.Windows.Forms.Label();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lblOldDetails = new System.Windows.Forms.Label();
            this.lblNewDetails = new System.Windows.Forms.Label();
            this.btnEditFirstName = new System.Windows.Forms.Button();
            this.lblLastNameText = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.btnEditLastName = new System.Windows.Forms.Button();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.tbNewPassword = new System.Windows.Forms.TextBox();
            this.lblEmailText = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.btnEditEmail = new System.Windows.Forms.Button();
            this.tbSecretWord = new System.Windows.Forms.TextBox();
            this.tbNewSecretWord = new System.Windows.Forms.TextBox();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSelectAssignment = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.btnThemeLight = new System.Windows.Forms.Button();
            this.btnThemeMidnight = new System.Windows.Forms.Button();
            this.btnThemeNormal = new System.Windows.Forms.Button();
            this.btnThemeDark = new System.Windows.Forms.Button();
            this.flpAccountList = new System.Windows.Forms.FlowLayoutPanel();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblAssignments = new System.Windows.Forms.Label();
            this.btnRemoveAssignment = new System.Windows.Forms.Button();
            this.btnAddAssignment = new System.Windows.Forms.Button();
            this.tbAddAssignment = new System.Windows.Forms.TextBox();
            this.lblAddAssignmentName = new System.Windows.Forms.Label();
            this.lblAssignmentsText = new System.Windows.Forms.Label();
            this.pnlAssignment = new System.Windows.Forms.Panel();
            this.lblAssosiatedModule = new System.Windows.Forms.Label();
            this.tbAssosiatedModule = new System.Windows.Forms.TextBox();
            this.lblAssignmentNumber = new System.Windows.Forms.Label();
            this.lblAssignmentAdvice = new System.Windows.Forms.Label();
            this.btnModuleManagement = new System.Windows.Forms.Button();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnManageCourses = new System.Windows.Forms.Button();
            this.tlpField.SuspendLayout();
            this.pnlAssignment.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLayout
            // 
            this.lblLayout.BackColor = System.Drawing.Color.Transparent;
            this.lblLayout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLayout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblLayout.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLayout.Location = new System.Drawing.Point(1295, 787);
            this.lblLayout.Name = "lblLayout";
            this.lblLayout.Size = new System.Drawing.Size(152, 40);
            this.lblLayout.TabIndex = 57;
            this.lblLayout.Text = "Layout";
            // 
            // btnEditSecretWord
            // 
            this.btnEditSecretWord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditSecretWord.Location = new System.Drawing.Point(726, 223);
            this.btnEditSecretWord.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditSecretWord.Name = "btnEditSecretWord";
            this.btnEditSecretWord.Size = new System.Drawing.Size(62, 33);
            this.btnEditSecretWord.TabIndex = 55;
            this.btnEditSecretWord.Text = "Edit";
            this.btnEditSecretWord.UseVisualStyleBackColor = true;
            this.btnEditSecretWord.Click += new System.EventHandler(this.btnEditSecretWord_Click);
            // 
            // btnEditPassword
            // 
            this.btnEditPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditPassword.Location = new System.Drawing.Point(726, 129);
            this.btnEditPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditPassword.Name = "btnEditPassword";
            this.btnEditPassword.Size = new System.Drawing.Size(62, 33);
            this.btnEditPassword.TabIndex = 54;
            this.btnEditPassword.Text = "Edit";
            this.btnEditPassword.UseVisualStyleBackColor = true;
            this.btnEditPassword.Click += new System.EventHandler(this.btnEditPassword_Click);
            // 
            // tlpField
            // 
            this.tlpField.ColumnCount = 5;
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpField.Controls.Add(this.lblSecretWord, 0, 5);
            this.tlpField.Controls.Add(this.lblEmail, 0, 4);
            this.tlpField.Controls.Add(this.lblPassword, 0, 3);
            this.tlpField.Controls.Add(this.lblLastName, 0, 2);
            this.tlpField.Controls.Add(this.lblFirstName, 0, 1);
            this.tlpField.Controls.Add(this.lblPasswordMessage, 4, 3);
            this.tlpField.Controls.Add(this.lblSecretWordMessage, 4, 5);
            this.tlpField.Controls.Add(this.lblFirstNameText, 1, 1);
            this.tlpField.Controls.Add(this.tbFirstName, 2, 1);
            this.tlpField.Controls.Add(this.lblOldDetails, 1, 0);
            this.tlpField.Controls.Add(this.lblNewDetails, 2, 0);
            this.tlpField.Controls.Add(this.btnEditFirstName, 3, 1);
            this.tlpField.Controls.Add(this.lblLastNameText, 1, 2);
            this.tlpField.Controls.Add(this.tbLastName, 2, 2);
            this.tlpField.Controls.Add(this.btnEditLastName, 3, 2);
            this.tlpField.Controls.Add(this.tbPassword, 1, 3);
            this.tlpField.Controls.Add(this.tbNewPassword, 2, 3);
            this.tlpField.Controls.Add(this.btnEditPassword, 3, 3);
            this.tlpField.Controls.Add(this.lblEmailText, 1, 4);
            this.tlpField.Controls.Add(this.tbEmail, 2, 4);
            this.tlpField.Controls.Add(this.btnEditEmail, 3, 4);
            this.tlpField.Controls.Add(this.tbSecretWord, 1, 5);
            this.tlpField.Controls.Add(this.tbNewSecretWord, 2, 5);
            this.tlpField.Controls.Add(this.btnEditSecretWord, 3, 5);
            this.tlpField.Location = new System.Drawing.Point(6, 157);
            this.tlpField.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tlpField.Name = "tlpField";
            this.tlpField.RowCount = 6;
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpField.Size = new System.Drawing.Size(1062, 268);
            this.tlpField.TabIndex = 53;
            // 
            // lblSecretWord
            // 
            this.lblSecretWord.AutoSize = true;
            this.lblSecretWord.Location = new System.Drawing.Point(4, 218);
            this.lblSecretWord.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSecretWord.Name = "lblSecretWord";
            this.lblSecretWord.Size = new System.Drawing.Size(102, 20);
            this.lblSecretWord.TabIndex = 40;
            this.lblSecretWord.Text = "Secret Word:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(4, 171);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(52, 20);
            this.lblEmail.TabIndex = 39;
            this.lblEmail.Text = "Email:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(4, 124);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(82, 20);
            this.lblPassword.TabIndex = 38;
            this.lblPassword.Text = "Password:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(4, 77);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(90, 20);
            this.lblLastName.TabIndex = 68;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(4, 30);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(90, 20);
            this.lblFirstName.TabIndex = 69;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblPasswordMessage
            // 
            this.lblPasswordMessage.AutoSize = true;
            this.lblPasswordMessage.Location = new System.Drawing.Point(795, 124);
            this.lblPasswordMessage.Name = "lblPasswordMessage";
            this.lblPasswordMessage.Size = new System.Drawing.Size(247, 20);
            this.lblPasswordMessage.TabIndex = 91;
            this.lblPasswordMessage.Text = "Please enter old password to edit.";
            this.lblPasswordMessage.Visible = false;
            // 
            // lblSecretWordMessage
            // 
            this.lblSecretWordMessage.AutoSize = true;
            this.lblSecretWordMessage.Location = new System.Drawing.Point(795, 218);
            this.lblSecretWordMessage.Name = "lblSecretWordMessage";
            this.lblSecretWordMessage.Size = new System.Drawing.Size(261, 20);
            this.lblSecretWordMessage.TabIndex = 92;
            this.lblSecretWordMessage.Text = "Please enter old secret word to edit.";
            this.lblSecretWordMessage.Visible = false;
            // 
            // lblFirstNameText
            // 
            this.lblFirstNameText.AutoSize = true;
            this.lblFirstNameText.Location = new System.Drawing.Point(113, 30);
            this.lblFirstNameText.Name = "lblFirstNameText";
            this.lblFirstNameText.Size = new System.Drawing.Size(18, 20);
            this.lblFirstNameText.TabIndex = 95;
            this.lblFirstNameText.Text = "_";
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(419, 33);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(300, 26);
            this.tbFirstName.TabIndex = 70;
            this.tbFirstName.TextChanged += new System.EventHandler(this.tbFirstName_TextChanged);
            // 
            // lblOldDetails
            // 
            this.lblOldDetails.AutoSize = true;
            this.lblOldDetails.Location = new System.Drawing.Point(113, 0);
            this.lblOldDetails.Name = "lblOldDetails";
            this.lblOldDetails.Size = new System.Drawing.Size(83, 20);
            this.lblOldDetails.TabIndex = 101;
            this.lblOldDetails.Text = "Old details";
            // 
            // lblNewDetails
            // 
            this.lblNewDetails.AutoSize = true;
            this.lblNewDetails.Location = new System.Drawing.Point(419, 0);
            this.lblNewDetails.Name = "lblNewDetails";
            this.lblNewDetails.Size = new System.Drawing.Size(90, 20);
            this.lblNewDetails.TabIndex = 102;
            this.lblNewDetails.Text = "New details";
            // 
            // btnEditFirstName
            // 
            this.btnEditFirstName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditFirstName.Location = new System.Drawing.Point(726, 35);
            this.btnEditFirstName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditFirstName.Name = "btnEditFirstName";
            this.btnEditFirstName.Size = new System.Drawing.Size(62, 33);
            this.btnEditFirstName.TabIndex = 63;
            this.btnEditFirstName.Text = "Edit";
            this.btnEditFirstName.UseVisualStyleBackColor = true;
            this.btnEditFirstName.Click += new System.EventHandler(this.btnEditFirstName_Click);
            // 
            // lblLastNameText
            // 
            this.lblLastNameText.AutoSize = true;
            this.lblLastNameText.Location = new System.Drawing.Point(113, 77);
            this.lblLastNameText.Name = "lblLastNameText";
            this.lblLastNameText.Size = new System.Drawing.Size(18, 20);
            this.lblLastNameText.TabIndex = 96;
            this.lblLastNameText.Text = "_";
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(419, 80);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(300, 26);
            this.tbLastName.TabIndex = 71;
            this.tbLastName.TextChanged += new System.EventHandler(this.tbLastName_TextChanged);
            // 
            // btnEditLastName
            // 
            this.btnEditLastName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditLastName.Location = new System.Drawing.Point(726, 82);
            this.btnEditLastName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditLastName.Name = "btnEditLastName";
            this.btnEditLastName.Size = new System.Drawing.Size(62, 33);
            this.btnEditLastName.TabIndex = 64;
            this.btnEditLastName.Text = "Edit";
            this.btnEditLastName.UseVisualStyleBackColor = true;
            this.btnEditLastName.Click += new System.EventHandler(this.btnEditLastName_Click);
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(113, 127);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(300, 26);
            this.tbPassword.TabIndex = 65;
            this.tbPassword.TextChanged += new System.EventHandler(this.tbPassword_TextChanged);
            // 
            // tbNewPassword
            // 
            this.tbNewPassword.Location = new System.Drawing.Point(419, 127);
            this.tbNewPassword.Name = "tbNewPassword";
            this.tbNewPassword.Size = new System.Drawing.Size(300, 26);
            this.tbNewPassword.TabIndex = 95;
            this.tbNewPassword.TextChanged += new System.EventHandler(this.tbNewPassword_TextChanged);
            // 
            // lblEmailText
            // 
            this.lblEmailText.AutoSize = true;
            this.lblEmailText.Location = new System.Drawing.Point(113, 171);
            this.lblEmailText.Name = "lblEmailText";
            this.lblEmailText.Size = new System.Drawing.Size(18, 20);
            this.lblEmailText.TabIndex = 99;
            this.lblEmailText.Text = "_";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(419, 174);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(300, 26);
            this.tbEmail.TabIndex = 66;
            this.tbEmail.TextChanged += new System.EventHandler(this.tbEmail_TextChanged);
            // 
            // btnEditEmail
            // 
            this.btnEditEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditEmail.Location = new System.Drawing.Point(726, 176);
            this.btnEditEmail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditEmail.Name = "btnEditEmail";
            this.btnEditEmail.Size = new System.Drawing.Size(62, 33);
            this.btnEditEmail.TabIndex = 62;
            this.btnEditEmail.Text = "Edit";
            this.btnEditEmail.UseVisualStyleBackColor = true;
            this.btnEditEmail.Click += new System.EventHandler(this.btnEditEmail_Click);
            // 
            // tbSecretWord
            // 
            this.tbSecretWord.Location = new System.Drawing.Point(113, 221);
            this.tbSecretWord.Name = "tbSecretWord";
            this.tbSecretWord.Size = new System.Drawing.Size(300, 26);
            this.tbSecretWord.TabIndex = 67;
            this.tbSecretWord.TextChanged += new System.EventHandler(this.tbSecretWord_TextChanged);
            // 
            // tbNewSecretWord
            // 
            this.tbNewSecretWord.Location = new System.Drawing.Point(419, 221);
            this.tbNewSecretWord.Name = "tbNewSecretWord";
            this.tbNewSecretWord.Size = new System.Drawing.Size(300, 26);
            this.tbNewSecretWord.TabIndex = 96;
            this.tbNewSecretWord.TextChanged += new System.EventHandler(this.tbNewSecretWord_TextChanged);
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 50;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSelectAssignment
            // 
            this.btnSelectAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectAssignment.Location = new System.Drawing.Point(1117, 3);
            this.btnSelectAssignment.Name = "btnSelectAssignment";
            this.btnSelectAssignment.Size = new System.Drawing.Size(160, 49);
            this.btnSelectAssignment.TabIndex = 48;
            this.btnSelectAssignment.Text = "Select Assignment";
            this.btnSelectAssignment.UseVisualStyleBackColor = true;
            this.btnSelectAssignment.Click += new System.EventHandler(this.btnSelectAssignment_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 47;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(140, 37);
            this.lblPageName.TabIndex = 46;
            this.lblPageName.Text = "Settings";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 44;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 45;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // btnThemeLight
            // 
            this.btnThemeLight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemeLight.Location = new System.Drawing.Point(1295, 831);
            this.btnThemeLight.Name = "btnThemeLight";
            this.btnThemeLight.Size = new System.Drawing.Size(152, 49);
            this.btnThemeLight.TabIndex = 61;
            this.btnThemeLight.Text = "Light";
            this.btnThemeLight.UseVisualStyleBackColor = true;
            this.btnThemeLight.Click += new System.EventHandler(this.btnThemeLight_Click);
            // 
            // btnThemeMidnight
            // 
            this.btnThemeMidnight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemeMidnight.Location = new System.Drawing.Point(1295, 996);
            this.btnThemeMidnight.Name = "btnThemeMidnight";
            this.btnThemeMidnight.Size = new System.Drawing.Size(152, 49);
            this.btnThemeMidnight.TabIndex = 62;
            this.btnThemeMidnight.Text = "Midnight";
            this.btnThemeMidnight.UseVisualStyleBackColor = true;
            this.btnThemeMidnight.Click += new System.EventHandler(this.btnThemeMidnight_Click);
            // 
            // btnThemeNormal
            // 
            this.btnThemeNormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemeNormal.Location = new System.Drawing.Point(1295, 886);
            this.btnThemeNormal.Name = "btnThemeNormal";
            this.btnThemeNormal.Size = new System.Drawing.Size(152, 49);
            this.btnThemeNormal.TabIndex = 63;
            this.btnThemeNormal.Text = "Normal";
            this.btnThemeNormal.UseVisualStyleBackColor = true;
            this.btnThemeNormal.Click += new System.EventHandler(this.btnThemeNormal_Click);
            // 
            // btnThemeDark
            // 
            this.btnThemeDark.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemeDark.Location = new System.Drawing.Point(1295, 941);
            this.btnThemeDark.Name = "btnThemeDark";
            this.btnThemeDark.Size = new System.Drawing.Size(152, 49);
            this.btnThemeDark.TabIndex = 64;
            this.btnThemeDark.Text = "Dark";
            this.btnThemeDark.UseVisualStyleBackColor = true;
            this.btnThemeDark.Click += new System.EventHandler(this.btnThemeDark_Click);
            // 
            // flpAccountList
            // 
            this.flpAccountList.AutoScroll = true;
            this.flpAccountList.Location = new System.Drawing.Point(5, 237);
            this.flpAccountList.Name = "flpAccountList";
            this.flpAccountList.Size = new System.Drawing.Size(1274, 372);
            this.flpAccountList.TabIndex = 90;
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1276, 40);
            this.lblPageAdvice.TabIndex = 93;
            this.lblPageAdvice.Text = "Enter new details in the related boxes to modify and old details pass codes.";
            // 
            // lblDetails
            // 
            this.lblDetails.BackColor = System.Drawing.Color.Transparent;
            this.lblDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.Location = new System.Drawing.Point(3, 112);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(799, 40);
            this.lblDetails.TabIndex = 96;
            this.lblDetails.Text = "Details";
            // 
            // lblAssignments
            // 
            this.lblAssignments.BackColor = System.Drawing.Color.Transparent;
            this.lblAssignments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAssignments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAssignments.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignments.Location = new System.Drawing.Point(3, 12);
            this.lblAssignments.Name = "lblAssignments";
            this.lblAssignments.Size = new System.Drawing.Size(1276, 40);
            this.lblAssignments.TabIndex = 99;
            this.lblAssignments.Text = "Assignments";
            // 
            // btnRemoveAssignment
            // 
            this.btnRemoveAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveAssignment.Location = new System.Drawing.Point(1094, 133);
            this.btnRemoveAssignment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRemoveAssignment.Name = "btnRemoveAssignment";
            this.btnRemoveAssignment.Size = new System.Drawing.Size(185, 36);
            this.btnRemoveAssignment.TabIndex = 100;
            this.btnRemoveAssignment.Text = "Remove assignment";
            this.btnRemoveAssignment.UseVisualStyleBackColor = true;
            this.btnRemoveAssignment.Click += new System.EventHandler(this.btnRemoveAssignment_Click);
            // 
            // btnAddAssignment
            // 
            this.btnAddAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddAssignment.Location = new System.Drawing.Point(475, 125);
            this.btnAddAssignment.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddAssignment.Name = "btnAddAssignment";
            this.btnAddAssignment.Size = new System.Drawing.Size(172, 36);
            this.btnAddAssignment.TabIndex = 101;
            this.btnAddAssignment.Text = "Add assignment";
            this.btnAddAssignment.UseVisualStyleBackColor = true;
            this.btnAddAssignment.Click += new System.EventHandler(this.btnAddAssignment_Click);
            // 
            // tbAddAssignment
            // 
            this.tbAddAssignment.Location = new System.Drawing.Point(168, 130);
            this.tbAddAssignment.Name = "tbAddAssignment";
            this.tbAddAssignment.Size = new System.Drawing.Size(300, 26);
            this.tbAddAssignment.TabIndex = 102;
            this.tbAddAssignment.TextChanged += new System.EventHandler(this.tbAddAssignment_TextChanged);
            // 
            // lblAddAssignmentName
            // 
            this.lblAddAssignmentName.AutoSize = true;
            this.lblAddAssignmentName.Location = new System.Drawing.Point(5, 133);
            this.lblAddAssignmentName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddAssignmentName.Name = "lblAddAssignmentName";
            this.lblAddAssignmentName.Size = new System.Drawing.Size(141, 20);
            this.lblAddAssignmentName.TabIndex = 103;
            this.lblAddAssignmentName.Text = "Assignment name:";
            // 
            // lblAssignmentsText
            // 
            this.lblAssignmentsText.AutoSize = true;
            this.lblAssignmentsText.Location = new System.Drawing.Point(7, 192);
            this.lblAssignmentsText.Name = "lblAssignmentsText";
            this.lblAssignmentsText.Size = new System.Drawing.Size(433, 20);
            this.lblAssignmentsText.TabIndex = 104;
            this.lblAssignmentsText.Text = "Could not add assignment. Is the assignment name unique?";
            this.lblAssignmentsText.Visible = false;
            // 
            // pnlAssignment
            // 
            this.pnlAssignment.Controls.Add(this.lblAssosiatedModule);
            this.pnlAssignment.Controls.Add(this.tbAssosiatedModule);
            this.pnlAssignment.Controls.Add(this.lblAssignmentNumber);
            this.pnlAssignment.Controls.Add(this.lblAssignmentAdvice);
            this.pnlAssignment.Controls.Add(this.lblAssignmentsText);
            this.pnlAssignment.Controls.Add(this.lblAssignments);
            this.pnlAssignment.Controls.Add(this.btnRemoveAssignment);
            this.pnlAssignment.Controls.Add(this.btnAddAssignment);
            this.pnlAssignment.Controls.Add(this.flpAccountList);
            this.pnlAssignment.Controls.Add(this.lblAddAssignmentName);
            this.pnlAssignment.Controls.Add(this.tbAddAssignment);
            this.pnlAssignment.Location = new System.Drawing.Point(3, 433);
            this.pnlAssignment.Name = "pnlAssignment";
            this.pnlAssignment.Size = new System.Drawing.Size(1290, 612);
            this.pnlAssignment.TabIndex = 105;
            // 
            // lblAssosiatedModule
            // 
            this.lblAssosiatedModule.AutoSize = true;
            this.lblAssosiatedModule.Location = new System.Drawing.Point(5, 163);
            this.lblAssosiatedModule.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAssosiatedModule.Name = "lblAssosiatedModule";
            this.lblAssosiatedModule.Size = new System.Drawing.Size(156, 20);
            this.lblAssosiatedModule.TabIndex = 109;
            this.lblAssosiatedModule.Text = "Assossiated Module:";
            // 
            // tbAssosiatedModule
            // 
            this.tbAssosiatedModule.Location = new System.Drawing.Point(168, 163);
            this.tbAssosiatedModule.Name = "tbAssosiatedModule";
            this.tbAssosiatedModule.Size = new System.Drawing.Size(300, 26);
            this.tbAssosiatedModule.TabIndex = 108;
            this.tbAssosiatedModule.TextChanged += new System.EventHandler(this.tbAssosiatedModule_TextChanged);
            // 
            // lblAssignmentNumber
            // 
            this.lblAssignmentNumber.AutoSize = true;
            this.lblAssignmentNumber.Location = new System.Drawing.Point(1091, 214);
            this.lblAssignmentNumber.Name = "lblAssignmentNumber";
            this.lblAssignmentNumber.Size = new System.Drawing.Size(18, 20);
            this.lblAssignmentNumber.TabIndex = 107;
            this.lblAssignmentNumber.Text = "_";
            // 
            // lblAssignmentAdvice
            // 
            this.lblAssignmentAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAssignmentAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssignmentAdvice.Location = new System.Drawing.Point(3, 61);
            this.lblAssignmentAdvice.Name = "lblAssignmentAdvice";
            this.lblAssignmentAdvice.Size = new System.Drawing.Size(1276, 59);
            this.lblAssignmentAdvice.TabIndex = 106;
            this.lblAssignmentAdvice.Text = "To remove an assignment select an assignment listed below and click remove assign" +
    "ment or add one by entering it\'s name and pressing add assignment.";
            // 
            // btnModuleManagement
            // 
            this.btnModuleManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModuleManagement.Location = new System.Drawing.Point(1125, 3);
            this.btnModuleManagement.Name = "btnModuleManagement";
            this.btnModuleManagement.Size = new System.Drawing.Size(152, 49);
            this.btnModuleManagement.TabIndex = 107;
            this.btnModuleManagement.Text = "Manage Modules";
            this.btnModuleManagement.UseVisualStyleBackColor = true;
            this.btnModuleManagement.Click += new System.EventHandler(this.btnModuleManagement_Click);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateAccount.Location = new System.Drawing.Point(955, 3);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(164, 49);
            this.btnCreateAccount.TabIndex = 106;
            this.btnCreateAccount.Text = "Manage Accounts";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnManageCourses
            // 
            this.btnManageCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCourses.Location = new System.Drawing.Point(785, 3);
            this.btnManageCourses.Name = "btnManageCourses";
            this.btnManageCourses.Size = new System.Drawing.Size(164, 49);
            this.btnManageCourses.TabIndex = 108;
            this.btnManageCourses.Text = "Manage Courses";
            this.btnManageCourses.UseVisualStyleBackColor = true;
            this.btnManageCourses.Click += new System.EventHandler(this.btnManageCourses_Click);
            // 
            // UserControl_Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.btnManageCourses);
            this.Controls.Add(this.btnModuleManagement);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.pnlAssignment);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.lblLayout);
            this.Controls.Add(this.btnThemeMidnight);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.btnThemeDark);
            this.Controls.Add(this.tlpField);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSelectAssignment);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.btnThemeLight);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnThemeNormal);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_Settings";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.tlpField.ResumeLayout(false);
            this.tlpField.PerformLayout();
            this.pnlAssignment.ResumeLayout(false);
            this.pnlAssignment.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblLayout;
        private System.Windows.Forms.Button btnEditSecretWord;
        private System.Windows.Forms.Button btnEditPassword;
        private System.Windows.Forms.TableLayoutPanel tlpField;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSecretWord;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSelectAssignment;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Button btnThemeDark;
        private System.Windows.Forms.Button btnThemeNormal;
        private System.Windows.Forms.Button btnThemeMidnight;
        private System.Windows.Forms.Button btnThemeLight;
        private System.Windows.Forms.Button btnEditEmail;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.Button btnEditFirstName;
        private System.Windows.Forms.Button btnEditLastName;
        private System.Windows.Forms.FlowLayoutPanel flpAccountList;
        private System.Windows.Forms.Label lblPasswordMessage;
        private System.Windows.Forms.Label lblSecretWordMessage;
        private System.Windows.Forms.Label lblNewDetails;
        private System.Windows.Forms.TextBox tbNewPassword;
        private System.Windows.Forms.TextBox tbNewSecretWord;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblFirstNameText;
        private System.Windows.Forms.Label lblOldDetails;
        private System.Windows.Forms.Label lblLastNameText;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label lblEmailText;
        private System.Windows.Forms.TextBox tbSecretWord;
        private System.Windows.Forms.Label lblAssignments;
        private System.Windows.Forms.Button btnRemoveAssignment;
        private System.Windows.Forms.Button btnAddAssignment;
        private System.Windows.Forms.TextBox tbAddAssignment;
        private System.Windows.Forms.Label lblAddAssignmentName;
        private System.Windows.Forms.Label lblAssignmentsText;
        private System.Windows.Forms.Panel pnlAssignment;
        private System.Windows.Forms.Label lblAssignmentAdvice;
        private System.Windows.Forms.Label lblAssignmentNumber;
        private System.Windows.Forms.Button btnModuleManagement;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Label lblAssosiatedModule;
        private System.Windows.Forms.TextBox tbAssosiatedModule;
        private System.Windows.Forms.Button btnManageCourses;
    }
}
