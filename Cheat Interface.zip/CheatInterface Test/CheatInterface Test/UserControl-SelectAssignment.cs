﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_SelectAssignment : UserControl
    {
        // Allowing access to functions in main class
        PageManagement pageManagement = PageManagement.GetInstance();
        DataManager dataManager = DataManager.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();

        // Lists for main class to access controls for colour changes
        private List<Label> labelList = new List<Label>();
        private List<Button> buttonList = new List<Button>();

        Button selectedCourseButton = null;
        Button selectedModuleButton = null;
        Color buttonBackColour;
        Color buttonForeColour;

        public UserControl_SelectAssignment()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            foreach (FlowLayoutPanel pagePanel in this.Controls.OfType<FlowLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }
            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);

            // Clear lists after use as they are no longer needed
            labelList.Clear();
            buttonList.Clear();

            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);
        }

        public void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                selectedCourseButton = null;
                selectedModuleButton = null;

                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                flpCourses.Controls.Clear();
                flpModules.Controls.Clear();
                flpAllModules.Controls.Clear();

                List<string> courseList = accountManager.accountLoggedIn.CoursesTaught;
                List<string> moduleList = accountManager.accountLoggedIn.ModulesTaught;

                foreach (string course in courseList)
                {
                    if (/*courseList.Count > 0 && */dataManager.CourseLookup.ContainsKey(course))
                    {
                        CreateCourseButton(course);
                    }
                }
                if (dataManager.CourseLookup.ContainsKey(courseList[0]))
                {
                    // if the first course exists in the course list then add all modules related to both it and the current user.
                    foreach (string moduleName in dataManager.CourseLookup[courseList[0]].CourseModuleNames)
                    {
                        if (moduleList.Contains(moduleName))
                        {
                            flpModules.Controls.Add(CreateModuleButton(moduleName));
                        }
                    }
                }
                foreach (string moduleName in accountManager.accountLoggedIn.ModulesTaught)
                {
                    flpAllModules.Controls.Add(CreateModuleButton(moduleName));
                }
            }
        }

        private Button CreateCourseButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Width = 200;
            button.Height = 50;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                selectedModuleButton = null;
                button.FlatStyle = FlatStyle.Standard;
                if (selectedCourseButton == null)
                {
                    selectedCourseButton = button;
                }
                else
                {
                    selectedCourseButton.FlatStyle = FlatStyle.Flat;
                    selectedCourseButton = button;
                }
                foreach (string moduleName in dataManager.CourseLookup[buttonName].CourseModuleNames)
                {
                    flpModules.Controls.Add(CreateModuleButton(moduleName));
                }
            };
            return button;
        }

        private Button CreateModuleButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Width = 200;
            button.Height = 50;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                button.FlatStyle = FlatStyle.Standard;
                if (selectedModuleButton == null)
                {
                    selectedModuleButton = button;
                }
                else
                {
                    selectedModuleButton.FlatStyle = FlatStyle.Flat;
                    selectedModuleButton = button;
                }
            };
            return button;
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("SelectAssignment", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("SelectAssignment", "UserHome");
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AllocateAssignments", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("AllocateAssignments", "Login");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("SelectAssignment");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("SelectAssignment");
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            dataManager.ModuleChosenForAssignments = selectedModuleButton.Name;
            pageManagement.ChangePage("AllocateAssignments", "AssignmentView");
        }
    }
}
