﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_Settings : UserControl
    {
        // Allowing access to functions in main class.
        PageManagement pageManagement = PageManagement.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        DataManager dataManager = DataManager.GetInstance();

        // Lists for main class to access controls for colour changes.
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();
        private List<TextBox> textBoxList = new List<TextBox>();

        Color buttonBackColour;
        Color buttonForeColour;
        Button selectedButton;

        public UserControl_Settings()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class.
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            foreach (Panel pagePanel in this.Controls.OfType<Panel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
                foreach (TextBox panelTextBox in pagePanel.Controls.OfType<TextBox>())
                {
                    textBoxList.Add(panelTextBox);
                }
            }

            foreach (TableLayoutPanel pagePanel in this.Controls.OfType<TableLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }
            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);

            // Clear lists after use as they are no longer needed.
            labelList.Clear();
            buttonList.Clear();
        }

        // Updates controls when visiting the page such as account details and colour schemes.
        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                Staff staff = accountManager.accountLoggedIn;

                lblFirstNameText.Text = staff.FirstName;
                lblLastNameText.Text = staff.LastName;
                lblEmailText.Text = staff.Email;

                // Admins do not control assignments and so have the feature removed.
                if (staff.IsAdmin == false)
                {
                    pnlAssignment.Visible = true;
                    lblAssignmentNumber.Text = " Number of assignments: " + staff.AssignmentLookup.Count.ToString();
                    lblPasswordMessage.Visible = false;
                    flpAccountList.Controls.Clear();

                    buttonBackColour = pageManagement.GetButtonBackColour();
                    buttonForeColour = pageManagement.GetButtonForeColour();

                    foreach (TextBox textbox in textBoxList)
                    {
                        textbox.Clear();
                    }
                    foreach (Assignment assignment in accountManager.accountLoggedIn.AssignmentLookup.Values)
                    {
                        flpAccountList.Controls.Add(CreateAssignmentButton(assignment.AssignmentName));
                    }
                    UpdateDynamicButtonColour();
                    btnSelectAssignment.Visible = true;

                    // Non admins cannot access these pages.
                    btnModuleManagement.Visible = false;
                    btnCreateAccount.Visible = false;
                }
                else
                {
                    pnlAssignment.Visible = false;
                    btnSelectAssignment.Visible = false;
                    btnModuleManagement.Visible = true;
                    btnCreateAccount.Visible = true;
                }
                btnAddAssignment.Enabled = false;
                btnEditEmail.Enabled = false;
                btnEditFirstName.Enabled = false;
                btnEditLastName.Enabled = false;
                btnEditPassword.Enabled = false;
                btnEditSecretWord.Enabled = false;
                btnRemoveAssignment.Enabled = false;
            }
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("Settings", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("Settings", "UserHome");
            }
        }

        private void btnSelectAssignment_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("Settings", "SelectAssignment");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("Settings", "Login");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("Settings");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("Settings");
        }

        private void btnThemeLight_Click(object sender, EventArgs e)
        {
            pageManagement.ChangeTheme("light");
            UpdateDynamicButtonColour();
        }

        private void btnThemeNormal_Click(object sender, EventArgs e)
        {
            pageManagement.ChangeTheme("normal");
            UpdateDynamicButtonColour();
        }

        private void btnThemeDark_Click(object sender, EventArgs e)
        {
            pageManagement.ChangeTheme("dark");
            UpdateDynamicButtonColour();
        }

        private void btnThemeMidnight_Click(object sender, EventArgs e)
        {
            pageManagement.ChangeTheme("midnight");
            UpdateDynamicButtonColour();
        }

        private void btnEditFirstName_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            account.FirstName = tbFirstName.Text;
            accountManager.updateAccount(account);
            tbFirstName.Clear();
            lblFirstNameText.Text = account.FirstName;
        }

        private void btnEditLastName_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            account.LastName = tbLastName.Text;
            accountManager.updateAccount(account);
            tbLastName.Clear();
            lblLastNameText.Text = account.LastName;
        }

        private void btnEditPassword_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            if (account.Password == tbPassword.Text)
            {
                account.Password = tbNewPassword.Text;
                accountManager.updateAccount(account);
                lblPasswordMessage.Visible = false;
            }
            else
            {
                lblPasswordMessage.Visible = true;
            }
            tbPassword.Clear();
            tbNewPassword.Clear();

        }

        private void btnEditEmail_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            account.Email = tbEmail.Text;
            accountManager.updateAccount(account);
            tbEmail.Clear();
            lblEmailText.Text = account.Email;
        }

        private void btnEditSecretWord_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            if (account.SecretWord == tbSecretWord.Text)
            {
                account.SecretWord = tbNewSecretWord.Text;
                accountManager.updateAccount(account);
                lblSecretWordMessage.Visible = false;
            }
            else
            {
                lblSecretWordMessage.Visible = true;
            }
            tbSecretWord.Clear();
            tbNewSecretWord.Clear();
        }

        // Adds a new assignment to the assignment list in the staff object and lists it in the assignment panel.
        private void btnAddAssignment_Click(object sender, EventArgs e)
        {
            Staff account = accountManager.GetAccount(accountManager.accountLoggedIn.UserName);
            Assignment assignment = new Assignment(account.UserName, tbAddAssignment.Text);
            if (account.AddAssignment(assignment))
            {
                accountManager.updateAccount(account);
                if (dataManager.ModuleLookup.ContainsKey(tbAssosiatedModule.Text))
                {
                    dataManager.ModuleLookup[tbAssosiatedModule.Text].ModuleAssignmentNames.Add(tbAddAssignment.Text);
                }
                flpAccountList.Controls.Add(CreateAssignmentButton(assignment.AssignmentName));
                ResetControls();
            }
            else
            {
                lblAssignmentsText.Visible = true;
            }
        }

        private void btnRemoveAssignment_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn.removeAssignment(selectedButton.Text);
            flpAccountList.Controls.Remove(selectedButton);
            selectedButton = null;
            ResetControls();
            btnRemoveAssignment.Enabled = false;

        }

        // Creates a button for the assignment panel representing a particular assignment.
        private Button CreateAssignmentButton(string assignmentName)
        {
            Button button = new Button();
            button.Name = assignmentName.Replace(" ", "");
            button.Text = assignmentName;
            button.Height = 60;
            button.Width = 120;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                // Make the new selected button stand out after resetting the old one and add it to the selectedButton for potential deletion.
                button.FlatStyle = FlatStyle.Standard;
                if (selectedButton == null)
                {
                    selectedButton = button;
                }
                else
                {
                    selectedButton.FlatStyle = FlatStyle.Flat;
                    selectedButton = button;
                }
                btnRemoveAssignment.Enabled = true;
            };
            return button;
        }

        private void ResetControls()
        {
            lblAssignmentsText.Visible = false;
            lblPasswordMessage.Visible = false;
            lblSecretWordMessage.Visible = false;
            lblAssignmentNumber.Text = " Number of assignments: " + accountManager.accountLoggedIn.AssignmentLookup.Count.ToString();
        }

        // Updates colours for dynamically created buttons as the settings page cannot rely on being updated via being made visible like other pages
        // (unless 'this.Visible' is set to false and true again which is less efficient).
        private void UpdateDynamicButtonColour()
        {
            buttonBackColour = pageManagement.GetButtonBackColour();
            buttonForeColour = pageManagement.GetButtonForeColour();
            // Buttons made dynamically on this page are not added the the button list in PageManagement to avoid needing
            // to call for the whole button list to remove them (given its size), colours are changed here instead.
            // Foreach for every panel is not used here to reduce the number of loops needed given the multiple nested panels.
            foreach (Button button in flpAccountList.Controls.OfType<Button>())
            {
                button.BackColor = buttonBackColour;
                button.ForeColor = buttonForeColour;
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("Settings", "CreateAccount");
        }

        private void btnModuleManagement_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("Settings", "ModuleManagement");
        }

        private void btnManageCourses_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("Settings", "CourseManagement");
        }

        // Event handlers for detecting when a user inputs text into the textbox in order to enable or disable buttons;
        private void tbFirstName_TextChanged(object sender, EventArgs e)
        {
            if (tbFirstName.Text != "")
            {
                btnEditFirstName.Enabled = true;
            }
            else
            {
                btnEditFirstName.Enabled = false;
            }
        }

        private void tbLastName_TextChanged(object sender, EventArgs e)
        {
            if (tbLastName.Text != "")
            {
                btnEditLastName.Enabled = true;
            }
            else
            {
                btnEditLastName.Enabled = false;
            }
        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {
            if (tbPassword.Text != "" && tbNewPassword.Text != "")
            {
                btnEditPassword.Enabled = true;
            }
            else
            {
                btnEditPassword.Enabled = false;
            }
        }

        private void tbNewPassword_TextChanged(object sender, EventArgs e)
        {
            if (tbPassword.Text != "" && tbNewPassword.Text != "")
            {
                btnEditPassword.Enabled = true;
            }
            else
            {
                btnEditPassword.Enabled = false;
            }
        }

        private void tbEmail_TextChanged(object sender, EventArgs e)
        {
            if (tbEmail.Text != "")
            {
                btnEditEmail.Enabled = true;
            }
            else
            {
                btnEditEmail.Enabled = false;
            }
        }

        private void tbSecretWord_TextChanged(object sender, EventArgs e)
        {
            if (tbSecretWord.Text != "" && tbNewSecretWord.Text != "")
            {
                btnEditSecretWord.Enabled = true;
            }
            else
            {
                btnEditSecretWord.Enabled = false;
            }
        }

        private void tbNewSecretWord_TextChanged(object sender, EventArgs e)
        {
            if (tbSecretWord.Text != "" && tbNewSecretWord.Text != "")
            {
                btnEditSecretWord.Enabled = true;
            }
            else
            {
                btnEditSecretWord.Enabled = false;
            }
        }

        private void tbAddAssignment_TextChanged(object sender, EventArgs e)
        {
            if (tbAddAssignment.Text != "" && tbAssosiatedModule.Text != "")
            {
                btnAddAssignment.Enabled = true;
            }
            else
            {
                btnAddAssignment.Enabled = false;
            }
        }

        private void tbAssosiatedModule_TextChanged(object sender, EventArgs e)
        {
            if (tbAddAssignment.Text != "" && tbAssosiatedModule.Text != "")
            {
                btnAddAssignment.Enabled = true;
            }
            else
            {
                btnAddAssignment.Enabled = false;
            }
        }
    }
}

