﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace CheatInterface_Test
{
    class PageManagement
    {
        // Allows for only one instance of PageManagement to be used to ensure all variables are shared.
        private static PageManagement instance = null;

        // Dictionary of pages in the application for reference when changing page at runtime and changing
        // the back colour of said pages.
        Dictionary<string, UserControl> pageList = new Dictionary<string, UserControl>();

        // Keeps track of which pages have been viewed in order for forward and back buttons.
        List<UserControl> pageHistoryList = new List<UserControl>();

        // Lists for accessing labels and buttons for all user controls for colour changes.
        List<Label> pageLabels = new List<Label>();
        List<Button> pageButtons = new List<Button>();
        List<RadioButton> pageRadioButtons = new List<RadioButton>();

        // Keeps track of the user's position in the history list of pages (user controls) visited.
        int backButtonSteps = 0;

        // Used to identify the user's position in pageHistoryList.
        int listPosition = 0;

        // Colour settings for the different user controls.
        Color labelForeColour;
        Color labelBackColour;
        Color buttonForeColour;
        Color buttonBackColour;
        Color userControlBackColour;
        
        public static PageManagement GetInstance()
        {
            if (instance == null)
            {
                instance = new PageManagement();
            }
            return instance;
        }

        // Color list for buttons used when dynamically creating new buttons.
        public Color GetButtonBackColour()
        {
            return buttonBackColour;
        }
        public Color GetButtonForeColour()
        {
            return buttonForeColour;
        }

        public void AddToPageList(string pageName, UserControl currentControl)
        {
            pageList.Add(pageName, currentControl);
        }

        public void AddToPageHistoryList(UserControl currentControl)
        {
            pageHistoryList.Add(currentControl);
        }

        public void AddToPageLabels(List<Label> newLabelList)
        {
            pageLabels.AddRange(newLabelList);
        }

        public void AddToPageButtons(List<Button> newButtonList)
        {
            pageButtons.AddRange(newButtonList);
        }

        public void AddToPageRadioButtons(List<RadioButton> newRadioButtonList)
        {
            pageRadioButtons.AddRange(newRadioButtonList);
        }

        public void ChangePage(string currentPage, string intendedPage)
        {
            if (backButtonSteps > 0)
            {
                pageHistoryList.RemoveRange((pageHistoryList.Count - (backButtonSteps)), (backButtonSteps));
                backButtonSteps = 0;
            }
            // Include next page in history list for forward button being within the list's bounds when returning to it, 
            // added first page at startup to compensate.
            if (pageList.ContainsKey(currentPage) && pageList.ContainsKey(intendedPage))
            {
                pageHistoryList.Add(pageList[intendedPage]);
                pageList[intendedPage].Visible = true;
                pageList[intendedPage].BringToFront();
                pageList[currentPage].Visible = false;
            }
        }
        public void BackButton(string currentPage)
        {
            if (pageHistoryList.Count > (backButtonSteps + 1))
            {
                backButtonSteps++;
                listPosition = pageHistoryList.Count - (backButtonSteps + 1);

                pageHistoryList[listPosition].Show();
                pageHistoryList[listPosition].BringToFront();
                pageList[currentPage].Hide();
            }
        }

        public void ForwardButton(string currentPage)
        {
            if (backButtonSteps > 0)
            {
                backButtonSteps--;

                listPosition = pageHistoryList.Count - (backButtonSteps + 1);

                pageHistoryList[listPosition].Show();
                pageHistoryList[listPosition].BringToFront();
                pageList[currentPage].Hide();
            }
        }

        public void ChangeTheme(string themeSetting)
        {
            // Settings for what each colour scheme should look like.
            if (themeSetting == "light")
            {
                labelForeColour = Color.Black;
                labelBackColour = Color.LightCyan;
                buttonForeColour = Color.Black;
                buttonBackColour = Color.LightBlue;
                userControlBackColour = Color.White;
            }
            else if (themeSetting == "normal")
            {
                labelForeColour = Color.Black;
                labelBackColour = Color.PapayaWhip;
                buttonForeColour = Color.Black;
                buttonBackColour = Color.Coral;
                userControlBackColour = Color.PapayaWhip;
            }
            else if (themeSetting == "dark")
            {
                labelForeColour = Color.LightCyan;
                labelBackColour = Color.FromArgb(32, 32, 32);
                buttonForeColour = Color.Black;
                buttonBackColour = Color.SkyBlue;
                userControlBackColour = Color.FromArgb(32, 32, 32);
            }
            else
            {
                labelForeColour = Color.LightGreen;
                labelBackColour = Color.Black;
                buttonForeColour = Color.LightCyan;
                buttonBackColour = Color.Green;
                userControlBackColour = Color.Black;
            }

            // Changing the colour scheme for the user controls.
            foreach (KeyValuePair<String, UserControl> u in pageList)
            {
                u.Value.BackColor = userControlBackColour;
            }
            foreach (Label l in pageLabels)
            {
                l.ForeColor = labelForeColour;
                l.BackColor = labelBackColour;
            }
            foreach (Button b in pageButtons)
            {
                b.ForeColor = buttonForeColour;
                b.BackColor = buttonBackColour;
            }
            foreach (RadioButton r in pageRadioButtons)
            {
                r.ForeColor = labelForeColour;
                r.BackColor = labelBackColour;
            }
        }
    }
}
