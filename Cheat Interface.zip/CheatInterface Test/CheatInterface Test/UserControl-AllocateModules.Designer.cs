﻿namespace CheatInterface_Test
{
    partial class UserControl_AllocateAssignments
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpModules = new System.Windows.Forms.FlowLayoutPanel();
            this.flpCourses = new System.Windows.Forms.FlowLayoutPanel();
            this.lblCourses = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.lblModules = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.btnModuleManagement = new System.Windows.Forms.Button();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.lblSelectedModules = new System.Windows.Forms.Label();
            this.lblModulesInAccount = new System.Windows.Forms.Label();
            this.flpSelectedModules = new System.Windows.Forms.FlowLayoutPanel();
            this.flpModulesInAccount = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // flpModules
            // 
            this.flpModules.AutoScroll = true;
            this.flpModules.BackColor = System.Drawing.Color.White;
            this.flpModules.Location = new System.Drawing.Point(327, 180);
            this.flpModules.Name = "flpModules";
            this.flpModules.Size = new System.Drawing.Size(318, 867);
            this.flpModules.TabIndex = 65;
            // 
            // flpCourses
            // 
            this.flpCourses.AutoScroll = true;
            this.flpCourses.BackColor = System.Drawing.Color.White;
            this.flpCourses.Location = new System.Drawing.Point(3, 180);
            this.flpCourses.Name = "flpCourses";
            this.flpCourses.Size = new System.Drawing.Size(318, 867);
            this.flpCourses.TabIndex = 64;
            // 
            // lblCourses
            // 
            this.lblCourses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblCourses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCourses.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourses.Location = new System.Drawing.Point(3, 143);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(318, 34);
            this.lblCourses.TabIndex = 61;
            this.lblCourses.Text = "Courses";
            // 
            // btnContinue
            // 
            this.btnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinue.Location = new System.Drawing.Point(1283, 60);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(152, 49);
            this.btnContinue.TabIndex = 60;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1274, 69);
            this.lblPageAdvice.TabIndex = 59;
            this.lblPageAdvice.Text = "Select which modules are taught then press Continue. Or select modules on the rig" +
    "ht to remove\r\nthem.";
            // 
            // lblModules
            // 
            this.lblModules.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblModules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblModules.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModules.Location = new System.Drawing.Point(327, 143);
            this.lblModules.Name = "lblModules";
            this.lblModules.Size = new System.Drawing.Size(314, 34);
            this.lblModules.TabIndex = 58;
            this.lblModules.Text = "Modules";
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 56;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 55;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 53;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(276, 37);
            this.lblPageName.TabIndex = 52;
            this.lblPageName.Text = "Allocate Modules";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 50;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 51;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // btnModuleManagement
            // 
            this.btnModuleManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModuleManagement.Location = new System.Drawing.Point(797, 3);
            this.btnModuleManagement.Name = "btnModuleManagement";
            this.btnModuleManagement.Size = new System.Drawing.Size(152, 49);
            this.btnModuleManagement.TabIndex = 69;
            this.btnModuleManagement.Text = "Manage Modules";
            this.btnModuleManagement.UseVisualStyleBackColor = true;
            this.btnModuleManagement.Click += new System.EventHandler(this.btnModuleManagement_Click);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateAccount.Location = new System.Drawing.Point(955, 3);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(164, 49);
            this.btnCreateAccount.TabIndex = 68;
            this.btnCreateAccount.Text = "Manage Accounts";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // lblSelectedModules
            // 
            this.lblSelectedModules.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblSelectedModules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectedModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSelectedModules.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedModules.Location = new System.Drawing.Point(803, 143);
            this.lblSelectedModules.Name = "lblSelectedModules";
            this.lblSelectedModules.Size = new System.Drawing.Size(320, 34);
            this.lblSelectedModules.TabIndex = 70;
            this.lblSelectedModules.Text = "Selected Modules";
            // 
            // lblModulesInAccount
            // 
            this.lblModulesInAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblModulesInAccount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblModulesInAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblModulesInAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModulesInAccount.Location = new System.Drawing.Point(1129, 143);
            this.lblModulesInAccount.Name = "lblModulesInAccount";
            this.lblModulesInAccount.Size = new System.Drawing.Size(320, 34);
            this.lblModulesInAccount.TabIndex = 71;
            this.lblModulesInAccount.Text = "Modules In Account";
            // 
            // flpSelectedModules
            // 
            this.flpSelectedModules.AutoScroll = true;
            this.flpSelectedModules.BackColor = System.Drawing.Color.White;
            this.flpSelectedModules.Location = new System.Drawing.Point(805, 180);
            this.flpSelectedModules.Name = "flpSelectedModules";
            this.flpSelectedModules.Size = new System.Drawing.Size(318, 867);
            this.flpSelectedModules.TabIndex = 72;
            // 
            // flpModulesInAccount
            // 
            this.flpModulesInAccount.AutoScroll = true;
            this.flpModulesInAccount.BackColor = System.Drawing.Color.White;
            this.flpModulesInAccount.Location = new System.Drawing.Point(1129, 180);
            this.flpModulesInAccount.Name = "flpModulesInAccount";
            this.flpModulesInAccount.Size = new System.Drawing.Size(318, 867);
            this.flpModulesInAccount.TabIndex = 73;
            // 
            // UserControl_AllocateAssignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flpModulesInAccount);
            this.Controls.Add(this.flpSelectedModules);
            this.Controls.Add(this.lblModulesInAccount);
            this.Controls.Add(this.lblSelectedModules);
            this.Controls.Add(this.btnModuleManagement);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.flpModules);
            this.Controls.Add(this.flpCourses);
            this.Controls.Add(this.lblCourses);
            this.Controls.Add(this.btnContinue);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.lblModules);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_AllocateAssignments";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flpModules;
        private System.Windows.Forms.FlowLayoutPanel flpCourses;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.Label lblModules;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Button btnModuleManagement;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Label lblSelectedModules;
        private System.Windows.Forms.Label lblModulesInAccount;
        private System.Windows.Forms.FlowLayoutPanel flpSelectedModules;
        private System.Windows.Forms.FlowLayoutPanel flpModulesInAccount;
    }
}
