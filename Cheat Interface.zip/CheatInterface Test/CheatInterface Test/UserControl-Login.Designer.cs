﻿namespace CheatInterface_Test
{
    partial class UserControlLogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlForgotPassword = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblSecretWord = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbSecretWord = new System.Windows.Forms.TextBox();
            this.btnForgotPassword = new System.Windows.Forms.Button();
            this.btnLogIn = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.lblIncorrectLoginMessage = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.pnlForgotPassword.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlForgotPassword
            // 
            this.pnlForgotPassword.Controls.Add(this.label1);
            this.pnlForgotPassword.Controls.Add(this.btnContinue);
            this.pnlForgotPassword.Controls.Add(this.lblEmail);
            this.pnlForgotPassword.Controls.Add(this.lblSecretWord);
            this.pnlForgotPassword.Controls.Add(this.tbEmail);
            this.pnlForgotPassword.Controls.Add(this.tbSecretWord);
            this.pnlForgotPassword.Location = new System.Drawing.Point(12, 409);
            this.pnlForgotPassword.Name = "pnlForgotPassword";
            this.pnlForgotPassword.Size = new System.Drawing.Size(1431, 318);
            this.pnlForgotPassword.TabIndex = 21;
            this.pnlForgotPassword.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(804, 32);
            this.label1.TabIndex = 11;
            this.label1.Text = "Please enter your email and secret word to reset the password.";
            // 
            // btnContinue
            // 
            this.btnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinue.Location = new System.Drawing.Point(399, 164);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(261, 48);
            this.btnContinue.TabIndex = 15;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(50, 65);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(80, 29);
            this.lblEmail.TabIndex = 11;
            this.lblEmail.Text = "Email:";
            // 
            // lblSecretWord
            // 
            this.lblSecretWord.AutoSize = true;
            this.lblSecretWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecretWord.Location = new System.Drawing.Point(50, 103);
            this.lblSecretWord.Name = "lblSecretWord";
            this.lblSecretWord.Size = new System.Drawing.Size(153, 29);
            this.lblSecretWord.TabIndex = 12;
            this.lblSecretWord.Text = "Secret Word:";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(208, 62);
            this.tbEmail.Multiline = true;
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(452, 35);
            this.tbEmail.TabIndex = 23;
            this.tbEmail.TextChanged += new System.EventHandler(this.tbEmail_TextChanged);
            // 
            // tbSecretWord
            // 
            this.tbSecretWord.Location = new System.Drawing.Point(208, 107);
            this.tbSecretWord.Multiline = true;
            this.tbSecretWord.Name = "tbSecretWord";
            this.tbSecretWord.Size = new System.Drawing.Size(452, 35);
            this.tbSecretWord.TabIndex = 24;
            this.tbSecretWord.TextChanged += new System.EventHandler(this.tbSecretWord_TextChanged);
            // 
            // btnForgotPassword
            // 
            this.btnForgotPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForgotPassword.Location = new System.Drawing.Point(12, 249);
            this.btnForgotPassword.Name = "btnForgotPassword";
            this.btnForgotPassword.Size = new System.Drawing.Size(261, 48);
            this.btnForgotPassword.TabIndex = 20;
            this.btnForgotPassword.Text = "Forgot Password?";
            this.btnForgotPassword.UseVisualStyleBackColor = true;
            this.btnForgotPassword.Click += new System.EventHandler(this.btnForgotPassword_Click);
            // 
            // btnLogIn
            // 
            this.btnLogIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogIn.Location = new System.Drawing.Point(339, 249);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(261, 48);
            this.btnLogIn.TabIndex = 19;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(12, 189);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(126, 29);
            this.lblPassword.TabIndex = 16;
            this.lblPassword.Text = "Password:";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(12, 148);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(130, 29);
            this.lblUsername.TabIndex = 15;
            this.lblUsername.Text = "Username:";
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.AutoSize = true;
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1419, 34);
            this.lblPageAdvice.TabIndex = 14;
            this.lblPageAdvice.Text = "Welcome to Submission Similarity Search Interface. Please log in to access servic" +
    "es.                                                ";
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(204, 18);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(281, 37);
            this.lblPageName.TabIndex = 13;
            this.lblPageName.Text = "Welcome to SSSI";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(12, 12);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 11;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(104, 12);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 12;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // lblIncoorectLoginMessage
            // 
            this.lblIncorrectLoginMessage.AutoSize = true;
            this.lblIncorrectLoginMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIncorrectLoginMessage.ForeColor = System.Drawing.Color.Black;
            this.lblIncorrectLoginMessage.Location = new System.Drawing.Point(12, 330);
            this.lblIncorrectLoginMessage.Name = "lblIncoorectLoginMessage";
            this.lblIncorrectLoginMessage.Size = new System.Drawing.Size(451, 32);
            this.lblIncorrectLoginMessage.TabIndex = 22;
            this.lblIncorrectLoginMessage.Text = "Incorrect Login: please try again";
            this.lblIncorrectLoginMessage.Visible = false;
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(148, 189);
            this.tbPassword.Multiline = true;
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(452, 35);
            this.tbPassword.TabIndex = 24;
            this.tbPassword.TextChanged += new System.EventHandler(this.tbPassword_TextChanged);
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(148, 148);
            this.tbUsername.Multiline = true;
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(452, 35);
            this.tbUsername.TabIndex = 25;
            this.tbUsername.TextChanged += new System.EventHandler(this.tbUsername_TextChanged);
            // 
            // UserControlLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.lblIncorrectLoginMessage);
            this.Controls.Add(this.pnlForgotPassword);
            this.Controls.Add(this.btnForgotPassword);
            this.Controls.Add(this.btnLogIn);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Controls.Add(this.tbUsername);
            this.Controls.Add(this.tbPassword);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "UserControlLogin";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.Load += new System.EventHandler(this.UserControlLogin_Load);
            this.pnlForgotPassword.ResumeLayout(false);
            this.pnlForgotPassword.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlForgotPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSecretWord;
        private System.Windows.Forms.Button btnForgotPassword;
        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Label lblIncorrectLoginMessage;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbSecretWord;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.TextBox tbUsername;
    }
}
