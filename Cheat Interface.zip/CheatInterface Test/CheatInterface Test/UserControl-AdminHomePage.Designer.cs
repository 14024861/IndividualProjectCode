﻿namespace CheatInterface_Test
{
    partial class UserControl_AdminHomePage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.btnModuleManagement = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.lblLoadFromFile = new System.Windows.Forms.Label();
            this.lblSaveToFile = new System.Windows.Forms.Label();
            this.btnLoadStaff = new System.Windows.Forms.Button();
            this.btnLoadAssignments = new System.Windows.Forms.Button();
            this.btnSaveAssignments = new System.Windows.Forms.Button();
            this.btnSaveStaff = new System.Windows.Forms.Button();
            this.btnSaveStudents = new System.Windows.Forms.Button();
            this.btnLoadStudents = new System.Windows.Forms.Button();
            this.btnLoadModules = new System.Windows.Forms.Button();
            this.btnSaveModules = new System.Windows.Forms.Button();
            this.btnLoadCourses = new System.Windows.Forms.Button();
            this.btnSaveCourse = new System.Windows.Forms.Button();
            this.btnManageCourses = new System.Windows.Forms.Button();
            this.lblAdminMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateAccount.Location = new System.Drawing.Point(627, 3);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(164, 49);
            this.btnCreateAccount.TabIndex = 37;
            this.btnCreateAccount.Text = "Manage Accounts";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 34;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 33;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(202, 37);
            this.lblPageName.TabIndex = 30;
            this.lblPageName.Text = "Admin Page";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 28;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 29;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // btnModuleManagement
            // 
            this.btnModuleManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModuleManagement.Location = new System.Drawing.Point(967, 3);
            this.btnModuleManagement.Name = "btnModuleManagement";
            this.btnModuleManagement.Size = new System.Drawing.Size(152, 49);
            this.btnModuleManagement.TabIndex = 40;
            this.btnModuleManagement.Text = "Manage Modules";
            this.btnModuleManagement.UseVisualStyleBackColor = true;
            this.btnModuleManagement.Click += new System.EventHandler(this.btnModuleManagement_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.AutoSize = true;
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(231, 34);
            this.lblPageAdvice.TabIndex = 41;
            this.lblPageAdvice.Text = "Welcome Admin.";
            // 
            // lblLoadFromFile
            // 
            this.lblLoadFromFile.BackColor = System.Drawing.Color.Transparent;
            this.lblLoadFromFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLoadFromFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblLoadFromFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadFromFile.Location = new System.Drawing.Point(3, 121);
            this.lblLoadFromFile.Name = "lblLoadFromFile";
            this.lblLoadFromFile.Size = new System.Drawing.Size(231, 34);
            this.lblLoadFromFile.TabIndex = 86;
            this.lblLoadFromFile.Text = "Load From File";
            // 
            // lblSaveToFile
            // 
            this.lblSaveToFile.BackColor = System.Drawing.Color.Transparent;
            this.lblSaveToFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSaveToFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSaveToFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaveToFile.Location = new System.Drawing.Point(250, 121);
            this.lblSaveToFile.Name = "lblSaveToFile";
            this.lblSaveToFile.Size = new System.Drawing.Size(231, 34);
            this.lblSaveToFile.TabIndex = 87;
            this.lblSaveToFile.Text = "Save To File";
            // 
            // btnLoadStaff
            // 
            this.btnLoadStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadStaff.Location = new System.Drawing.Point(3, 158);
            this.btnLoadStaff.Name = "btnLoadStaff";
            this.btnLoadStaff.Size = new System.Drawing.Size(231, 49);
            this.btnLoadStaff.TabIndex = 88;
            this.btnLoadStaff.Text = "Staff";
            this.btnLoadStaff.UseVisualStyleBackColor = true;
            this.btnLoadStaff.Click += new System.EventHandler(this.btnLoadStaff_Click);
            // 
            // btnLoadAssignments
            // 
            this.btnLoadAssignments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadAssignments.Location = new System.Drawing.Point(3, 418);
            this.btnLoadAssignments.Name = "btnLoadAssignments";
            this.btnLoadAssignments.Size = new System.Drawing.Size(231, 49);
            this.btnLoadAssignments.TabIndex = 89;
            this.btnLoadAssignments.Text = "Assignments";
            this.btnLoadAssignments.UseVisualStyleBackColor = true;
            this.btnLoadAssignments.Click += new System.EventHandler(this.btnLoadAssignments_Click);
            // 
            // btnSaveAssignments
            // 
            this.btnSaveAssignments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveAssignments.Location = new System.Drawing.Point(250, 418);
            this.btnSaveAssignments.Name = "btnSaveAssignments";
            this.btnSaveAssignments.Size = new System.Drawing.Size(231, 49);
            this.btnSaveAssignments.TabIndex = 91;
            this.btnSaveAssignments.Text = "Assignments";
            this.btnSaveAssignments.UseVisualStyleBackColor = true;
            this.btnSaveAssignments.Click += new System.EventHandler(this.btnSaveAssignments_Click);
            // 
            // btnSaveStaff
            // 
            this.btnSaveStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveStaff.Location = new System.Drawing.Point(250, 158);
            this.btnSaveStaff.Name = "btnSaveStaff";
            this.btnSaveStaff.Size = new System.Drawing.Size(231, 49);
            this.btnSaveStaff.TabIndex = 90;
            this.btnSaveStaff.Text = "Staff";
            this.btnSaveStaff.UseVisualStyleBackColor = true;
            this.btnSaveStaff.Click += new System.EventHandler(this.btnSaveStaff_Click);
            // 
            // btnSaveStudents
            // 
            this.btnSaveStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveStudents.Location = new System.Drawing.Point(250, 223);
            this.btnSaveStudents.Name = "btnSaveStudents";
            this.btnSaveStudents.Size = new System.Drawing.Size(231, 49);
            this.btnSaveStudents.TabIndex = 93;
            this.btnSaveStudents.Text = "Student";
            this.btnSaveStudents.UseVisualStyleBackColor = true;
            this.btnSaveStudents.Click += new System.EventHandler(this.btnSaveStudents_Click);
            // 
            // btnLoadStudents
            // 
            this.btnLoadStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadStudents.Location = new System.Drawing.Point(3, 223);
            this.btnLoadStudents.Name = "btnLoadStudents";
            this.btnLoadStudents.Size = new System.Drawing.Size(231, 49);
            this.btnLoadStudents.TabIndex = 92;
            this.btnLoadStudents.Text = "Student";
            this.btnLoadStudents.UseVisualStyleBackColor = true;
            this.btnLoadStudents.Click += new System.EventHandler(this.btnLoadStudents_Click);
            // 
            // btnLoadModules
            // 
            this.btnLoadModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadModules.Location = new System.Drawing.Point(3, 353);
            this.btnLoadModules.Name = "btnLoadModules";
            this.btnLoadModules.Size = new System.Drawing.Size(231, 49);
            this.btnLoadModules.TabIndex = 95;
            this.btnLoadModules.Text = "Modules";
            this.btnLoadModules.UseVisualStyleBackColor = true;
            this.btnLoadModules.Click += new System.EventHandler(this.btnLoadModules_Click);
            // 
            // btnSaveModules
            // 
            this.btnSaveModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveModules.Location = new System.Drawing.Point(250, 353);
            this.btnSaveModules.Name = "btnSaveModules";
            this.btnSaveModules.Size = new System.Drawing.Size(231, 49);
            this.btnSaveModules.TabIndex = 94;
            this.btnSaveModules.Text = "Modules";
            this.btnSaveModules.UseVisualStyleBackColor = true;
            this.btnSaveModules.Click += new System.EventHandler(this.btnSaveModules_Click);
            // 
            // btnLoadCourses
            // 
            this.btnLoadCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadCourses.Location = new System.Drawing.Point(3, 288);
            this.btnLoadCourses.Name = "btnLoadCourses";
            this.btnLoadCourses.Size = new System.Drawing.Size(231, 49);
            this.btnLoadCourses.TabIndex = 97;
            this.btnLoadCourses.Text = "Course";
            this.btnLoadCourses.UseVisualStyleBackColor = true;
            this.btnLoadCourses.Click += new System.EventHandler(this.btnLoadCourses_Click);
            // 
            // btnSaveCourse
            // 
            this.btnSaveCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveCourse.Location = new System.Drawing.Point(250, 288);
            this.btnSaveCourse.Name = "btnSaveCourse";
            this.btnSaveCourse.Size = new System.Drawing.Size(231, 49);
            this.btnSaveCourse.TabIndex = 96;
            this.btnSaveCourse.Text = "Course";
            this.btnSaveCourse.UseVisualStyleBackColor = true;
            this.btnSaveCourse.Click += new System.EventHandler(this.btnSaveCourse_Click);
            // 
            // btnManageCourses
            // 
            this.btnManageCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCourses.Location = new System.Drawing.Point(797, 3);
            this.btnManageCourses.Name = "btnManageCourses";
            this.btnManageCourses.Size = new System.Drawing.Size(164, 49);
            this.btnManageCourses.TabIndex = 102;
            this.btnManageCourses.Text = "Manage Courses";
            this.btnManageCourses.UseVisualStyleBackColor = true;
            this.btnManageCourses.Click += new System.EventHandler(this.btnManageCourses_Click);
            // 
            // lblAdminMessage
            // 
            this.lblAdminMessage.AutoSize = true;
            this.lblAdminMessage.Location = new System.Drawing.Point(3, 470);
            this.lblAdminMessage.Name = "lblAdminMessage";
            this.lblAdminMessage.Size = new System.Drawing.Size(18, 20);
            this.lblAdminMessage.TabIndex = 103;
            this.lblAdminMessage.Text = "_";
            // 
            // UserControl_AdminHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.lblAdminMessage);
            this.Controls.Add(this.btnManageCourses);
            this.Controls.Add(this.btnLoadCourses);
            this.Controls.Add(this.btnSaveCourse);
            this.Controls.Add(this.btnLoadModules);
            this.Controls.Add(this.btnSaveModules);
            this.Controls.Add(this.btnSaveStudents);
            this.Controls.Add(this.btnLoadStudents);
            this.Controls.Add(this.btnSaveAssignments);
            this.Controls.Add(this.btnSaveStaff);
            this.Controls.Add(this.btnLoadAssignments);
            this.Controls.Add(this.btnLoadStaff);
            this.Controls.Add(this.lblSaveToFile);
            this.Controls.Add(this.lblLoadFromFile);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.btnModuleManagement);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_AdminHomePage";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Button btnModuleManagement;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.Label lblLoadFromFile;
        private System.Windows.Forms.Label lblSaveToFile;
        private System.Windows.Forms.Button btnLoadStaff;
        private System.Windows.Forms.Button btnLoadAssignments;
        private System.Windows.Forms.Button btnSaveAssignments;
        private System.Windows.Forms.Button btnSaveStaff;
        private System.Windows.Forms.Button btnSaveStudents;
        private System.Windows.Forms.Button btnLoadStudents;
        private System.Windows.Forms.Button btnLoadModules;
        private System.Windows.Forms.Button btnSaveModules;
        private System.Windows.Forms.Button btnLoadCourses;
        private System.Windows.Forms.Button btnSaveCourse;
        private System.Windows.Forms.Button btnManageCourses;
        private System.Windows.Forms.Label lblAdminMessage;
    }
}
