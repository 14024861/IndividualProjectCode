﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_CourseManagement : UserControl
    {
        // Allowing access to functions in main class.
        PageManagement pageManagement = PageManagement.GetInstance();
        DataManager dataManager = DataManager.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        Button selectedButton = null;

        // Lists for main class to access controls for colour changes.
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();

        Color buttonBackColour;
        Color buttonForeColour;

        public UserControl_CourseManagement()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class.
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);

            // Clear lists after use as they are no longer needed.
            labelList.Clear();
            buttonList.Clear();

            // Hide during runtime until needed.
            lblCourseMessage.Text = "";
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                ResetControls();

                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                flpCourseList.Controls.Clear();

                foreach (string courseName in dataManager.CourseLookup.Keys.ToList())
                {
                    flpCourseList.Controls.Add(CreateCourseButton(courseName));
                }
            }
            btnRemoveCourse.Enabled = false;
            btnCreateCourse.Enabled = false;
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("CourseManagement");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("CourseManagement");

        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("CourseManagement", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("CourseManagement", "UserHome");
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CourseManagement", "CreateAccount");
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CourseManagement", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CourseManagement", "Login");
        }

        private void btnCreateCourse_Click(object sender, EventArgs e)
        {
            // Adds a course to the course list in DataManager or Staff if it doesn't already exist there.
            Course course = new Course(tbCourseName.Text);
            if (!dataManager.AddCourse(course))
            {
                if (accountManager.GetStaffAccountNames().Contains(tbStaffUsername.Text))
                {
                    if (accountManager.AddCourseToStaff(tbStaffUsername.Text, tbCourseName.Text))
                    {
                        lblCourseMessage.Text = "Course added to staff member";
                    }
                    else
                    {
                        lblCourseMessage.Text = "Course failed to be added. The staff member already has this course.";
                    }
                }
                else
                {
                    lblCourseMessage.Text = "Course failed to be added. The course name is not unique.";
                }

            }
            else
            {

                lblCourseMessage.Text = "Course added to courses.";
                flpCourseList.Controls.Add(CreateCourseButton(course.CourseName));
                if (!accountManager.GetStaffAccountNames().Contains(tbStaffUsername.Text))
                {
                    if (accountManager.AddCourseToStaff(tbStaffUsername.Text, tbCourseName.Text))
                    {
                        lblCourseMessage.Text = lblCourseMessage.Text + " Course added to staff member as well";
                    }
                }
            }
            ResetControls();
            btnCreateCourse.Enabled = false;
        }
    

        private void btnRemoveCourse_Click(object sender, EventArgs e)
        {
            if (selectedButton != null)
            {
                dataManager.DeleteCourse(dataManager.GetCourse(selectedButton.Name));
                flpCourseList.Controls.Remove(selectedButton);
                selectedButton = null;
                ResetControls();
                btnRemoveCourse.Enabled = false;
            }
        }

        private Button CreateCourseButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Width = 239;
            button.Height = 30;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;
            
            // Uses lambda function for implicit event handler, when clicked the submissions for this particular assignment are listed by a different function.
            button.Click += (object sender, EventArgs e) =>
            {
                button.FlatStyle = FlatStyle.Standard;
                if (selectedButton == null)
                {
                    selectedButton = button;
                }
                else
                {
                    selectedButton.FlatStyle = FlatStyle.Flat;
                    selectedButton = button;
                }
                btnRemoveCourse.Enabled = true;
            };
            return button;
        }

        private void ResetControls()
        {
            lblCourseMessage.Text = "";
            tbCourseName.Clear();
        }

        private void btnModuleManagement_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("CourseManagement", "ModuleManagement");
        }

        private void tbCourseName_TextChanged(object sender, EventArgs e)
        {
            if (tbCourseName.Text.Replace(" ", "") != "")
            {
                btnCreateCourse.Enabled = true;
            }
            else
            {
                btnCreateCourse.Enabled = false;
            }
        }
    }
}
