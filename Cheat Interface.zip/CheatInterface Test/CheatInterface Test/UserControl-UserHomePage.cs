﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_UserHomePage : UserControl
    {
        // Allowing access to functions in this class
        PageManagement pageManagement = PageManagement.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        DataManager dataManager = DataManager.GetInstance();

        // Lists for main class to access controls for colour changes
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();
        Color buttonBackColour;
        Color buttonForeColour;

        public UserControl_UserHomePage()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            foreach (FlowLayoutPanel pageButton in this.Controls.OfType<FlowLayoutPanel>())
            {
                foreach (Label l in pageButton.Controls.OfType<Label>())
                {
                    labelList.Add(l);
                }
            }
            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);

            // Clear lists after use as they are no longer needed
            labelList.Clear();
            buttonList.Clear();

            this.VisibleChanged += new EventHandler(UserControlVisibleChanged);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("UserHome", "Settings");
        }

        private void btnSelectAssignment_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("UserHome", "SelectAssignment");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("UserHome");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("UserHome");
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn != null)
            {
                flpTopSimilarities.Controls.Clear();
                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                lblPageAdvice.Text = "Welcome " + accountManager.accountLoggedIn.UserName + ".";
                foreach (Assignment assignment in accountManager.accountLoggedIn.AssignmentLookup.Values)
                {
                    foreach (Submission submission in assignment.AssignmentSubmissions)
                    {
                        int percentage;
                        if (Int32.TryParse(submission.PercentageSimilarity, out percentage))
                        {
                            if (percentage >= 50)
                            {
                                flpTopSimilarities.Controls.Add(CreateSubmissionButtons(submission));
                            }
                        }
                    }
                }
            }
        }

        public Button CreateSubmissionButtons(Submission submission)
        {
            // Clear the current buttons in the panel list and add new ones relevant to the assignment submission related to the referenced assignment.
            Button button = new Button();
            button.Name = submission.StudentID + submission.DocumentName.Replace(" ", "");
            button.Text = submission.DocumentName + System.Environment.NewLine + submission.PercentageSimilarity + " | " + submission.StudentID + " | " +
                          submission.SubmissionDate;
            button.Width = 235;
            button.Height = 60;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;

            button.Click += (object sender, EventArgs e) =>
            {
                dataManager.ModuleChosenForAssignments = button.Text;
                pageManagement.ChangePage("UserHome", "AssignmentView");
            };

            return button;
        }


        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("UserHome", "Login");
        }

    }
}
