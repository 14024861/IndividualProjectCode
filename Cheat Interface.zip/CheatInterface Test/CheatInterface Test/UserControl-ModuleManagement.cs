﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataModel;

namespace CheatInterface_Test
{
    public partial class ModuleManagement : UserControl
    {
        // Allowing access to functions in main class.
        PageManagement pageManagement = PageManagement.GetInstance();
        DataManager dataManager = DataManager.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        Button selectedButton = null;

        // Lists for main class to access controls for colour changes.
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();

        Color buttonBackColour;
        Color buttonForeColour;

        public ModuleManagement()
        {
            InitializeComponent();

            // Adding all labels and buttons to list for colour changes in pageManagement class.
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }

            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);

            // Clear lists after use as they are no longer needed.
            labelList.Clear();
            buttonList.Clear();

            // Hide during runtime until needed.
            lblModuleMessage.Text = "";
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true)
            {
                ResetControls();

                buttonBackColour = pageManagement.GetButtonBackColour();
                buttonForeColour = pageManagement.GetButtonForeColour();

                flpModuleList.Controls.Clear();

                foreach (string moduleName in dataManager.ModuleLookup.Keys.ToList())
                {
                    flpModuleList.Controls.Add(CreateModuleButton(moduleName));
                }
                btnCreateModule.Enabled = false;
                btnRemoveModule.Enabled = false;
            }
        }

        private void btnCreateModule_Click(object sender, EventArgs e)
        {
            Module module = new Module(tbModuleName.Text);
            if (!dataManager.AddModule(module))
            {
                lblModuleMessage.Text = "Module failed to be added. The module name is not unique.";
            }
            else
            {
                lblModuleMessage.Text = "Module added to modules.";
                flpModuleList.Controls.Add(CreateModuleButton(module.ModuleName));
                if (dataManager.CourseLookup.ContainsKey(tbAssociatedCourse.Text))
                {
                    dataManager.CourseLookup[tbAssociatedCourse.Text].CourseModuleNames.Add(tbModuleName.Text);
                }
                ResetControls();
                btnCreateModule.Enabled = false;
                btnRemoveModule.Enabled = false;
            }

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("ModuleManagement", "Login");
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            if (accountManager.accountLoggedIn.IsAdmin == true)
            {
                pageManagement.ChangePage("ModuleManagement", "AdminHome");
            }
            else
            {
                pageManagement.ChangePage("ModuleManagement", "UserHome");
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("ModuleManagement", "Settings");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("ModuleManagement");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("ModuleManagement");
        }

        private Button CreateModuleButton(string buttonName)
        {
            Button button = new Button();
            button.Name = buttonName.Replace(" ", "");
            button.Text = buttonName;
            button.Width = 150;
            button.Height = 50;
            button.BackColor = buttonBackColour;
            button.ForeColor = buttonForeColour;
            button.FlatStyle = FlatStyle.Flat;
            
            button.Click += (object sender, EventArgs e) =>
            {
                button.FlatStyle = FlatStyle.Standard;
                if (selectedButton == null)
                {
                    selectedButton = button;
                }
                else
                {
                    selectedButton.FlatStyle = FlatStyle.Flat;
                    selectedButton = button;
                }
                btnRemoveModule.Enabled = true;
            };
            return button;
        }

        private void ResetControls()
        {
            lblModuleMessage.Text = "";
            tbModuleName.Clear();
        }

        private void btnRemoveModule_Click(object sender, EventArgs e)
        {
            if (selectedButton != null)
            {
                dataManager.DeleteModule(dataManager.GetModule(selectedButton.Name));
                flpModuleList.Controls.Remove(selectedButton);
                selectedButton = null;
                ResetControls();
                btnRemoveModule.Enabled = false;
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("ModuleManagement", "CreateAccount");
        }

        private void btnManageCourses_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("ModuleManagement", "CourseManagement");
        }

        private void tbModuleName_TextChanged(object sender, EventArgs e)
        {
            if (tbModuleName.Text.Replace(" ", "") != "")
            {
                btnCreateModule.Enabled = true;
            }
            else
            {
                btnCreateModule.Enabled = false;
            }
        }

        private void tbAssociatedCourse_TextChanged(object sender, EventArgs e)
        {
            if (tbModuleName.Text != "")
            {
                btnCreateModule.Enabled = true;
            }
            else
            {
                btnCreateModule.Enabled = false;
            }
        }
    }
}
