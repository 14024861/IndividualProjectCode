﻿namespace CheatInterface_Test
{
    partial class UserControl_CourseManagement
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.lblCourseName = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.lblNewCourse = new System.Windows.Forms.Label();
            this.btnCreateCourse = new System.Windows.Forms.Button();
            this.tbCourseName = new System.Windows.Forms.TextBox();
            this.lblCourseList = new System.Windows.Forms.Label();
            this.flpCourseList = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRemoveCourse = new System.Windows.Forms.Button();
            this.lblCourseMessage = new System.Windows.Forms.Label();
            this.btnModuleManagement = new System.Windows.Forms.Button();
            this.tbStaffUsername = new System.Windows.Forms.TextBox();
            this.lblRelatedStaffMember = new System.Windows.Forms.Label();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateAccount.Location = new System.Drawing.Point(955, 3);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(164, 49);
            this.btnCreateAccount.TabIndex = 106;
            this.btnCreateAccount.Text = "Manage Accounts";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // lblCourseName
            // 
            this.lblCourseName.AutoSize = true;
            this.lblCourseName.Location = new System.Drawing.Point(7, 148);
            this.lblCourseName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCourseName.Name = "lblCourseName";
            this.lblCourseName.Size = new System.Drawing.Size(110, 20);
            this.lblCourseName.TabIndex = 100;
            this.lblCourseName.Text = "Course Name:";
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 97;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 96;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 95;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(332, 37);
            this.lblPageName.TabIndex = 94;
            this.lblPageName.Text = "Course Management";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 92;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 93;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // lblNewCourse
            // 
            this.lblNewCourse.BackColor = System.Drawing.Color.Transparent;
            this.lblNewCourse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNewCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNewCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewCourse.Location = new System.Drawing.Point(3, 108);
            this.lblNewCourse.Name = "lblNewCourse";
            this.lblNewCourse.Size = new System.Drawing.Size(437, 34);
            this.lblNewCourse.TabIndex = 107;
            this.lblNewCourse.Text = "New Course";
            // 
            // btnCreateCourse
            // 
            this.btnCreateCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateCourse.Location = new System.Drawing.Point(446, 145);
            this.btnCreateCourse.Name = "btnCreateCourse";
            this.btnCreateCourse.Size = new System.Drawing.Size(152, 49);
            this.btnCreateCourse.TabIndex = 108;
            this.btnCreateCourse.Text = "Add Course";
            this.btnCreateCourse.UseVisualStyleBackColor = true;
            this.btnCreateCourse.Click += new System.EventHandler(this.btnCreateCourse_Click);
            // 
            // tbCourseName
            // 
            this.tbCourseName.Location = new System.Drawing.Point(137, 145);
            this.tbCourseName.Name = "tbCourseName";
            this.tbCourseName.Size = new System.Drawing.Size(303, 26);
            this.tbCourseName.TabIndex = 109;
            this.tbCourseName.TextChanged += new System.EventHandler(this.tbCourseName_TextChanged);
            // 
            // lblCourseList
            // 
            this.lblCourseList.BackColor = System.Drawing.Color.Transparent;
            this.lblCourseList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCourseList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCourseList.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourseList.Location = new System.Drawing.Point(1074, 108);
            this.lblCourseList.Name = "lblCourseList";
            this.lblCourseList.Size = new System.Drawing.Size(361, 34);
            this.lblCourseList.TabIndex = 110;
            this.lblCourseList.Text = "Course List";
            // 
            // flpCourseList
            // 
            this.flpCourseList.Location = new System.Drawing.Point(1074, 146);
            this.flpCourseList.Name = "flpCourseList";
            this.flpCourseList.Size = new System.Drawing.Size(361, 842);
            this.flpCourseList.TabIndex = 111;
            // 
            // btnRemoveCourse
            // 
            this.btnRemoveCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveCourse.Location = new System.Drawing.Point(1235, 994);
            this.btnRemoveCourse.Name = "btnRemoveCourse";
            this.btnRemoveCourse.Size = new System.Drawing.Size(200, 49);
            this.btnRemoveCourse.TabIndex = 112;
            this.btnRemoveCourse.Text = "Remove Course";
            this.btnRemoveCourse.UseVisualStyleBackColor = true;
            this.btnRemoveCourse.Click += new System.EventHandler(this.btnRemoveCourse_Click);
            // 
            // lblCourseMessage
            // 
            this.lblCourseMessage.AutoSize = true;
            this.lblCourseMessage.Location = new System.Drawing.Point(7, 218);
            this.lblCourseMessage.Name = "lblCourseMessage";
            this.lblCourseMessage.Size = new System.Drawing.Size(18, 20);
            this.lblCourseMessage.TabIndex = 113;
            this.lblCourseMessage.Text = "_";
            // 
            // btnModuleManagement
            // 
            this.btnModuleManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModuleManagement.Location = new System.Drawing.Point(797, 3);
            this.btnModuleManagement.Name = "btnModuleManagement";
            this.btnModuleManagement.Size = new System.Drawing.Size(152, 49);
            this.btnModuleManagement.TabIndex = 114;
            this.btnModuleManagement.Text = "Manage Modules";
            this.btnModuleManagement.UseVisualStyleBackColor = true;
            this.btnModuleManagement.Click += new System.EventHandler(this.btnModuleManagement_Click);
            // 
            // tbStaffUsername
            // 
            this.tbStaffUsername.Location = new System.Drawing.Point(137, 185);
            this.tbStaffUsername.Name = "tbStaffUsername";
            this.tbStaffUsername.Size = new System.Drawing.Size(303, 26);
            this.tbStaffUsername.TabIndex = 116;
            // 
            // lblRelatedStaffMember
            // 
            this.lblRelatedStaffMember.AutoSize = true;
            this.lblRelatedStaffMember.Location = new System.Drawing.Point(7, 188);
            this.lblRelatedStaffMember.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRelatedStaffMember.Name = "lblRelatedStaffMember";
            this.lblRelatedStaffMember.Size = new System.Drawing.Size(123, 20);
            this.lblRelatedStaffMember.TabIndex = 115;
            this.lblRelatedStaffMember.Text = "Staff username:";
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1276, 34);
            this.lblPageAdvice.TabIndex = 117;
            this.lblPageAdvice.Text = "Enter Course name to add course. Select or add course with staff username to add " +
    "course to staff.";
            // 
            // UserControl_CourseManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.tbStaffUsername);
            this.Controls.Add(this.lblRelatedStaffMember);
            this.Controls.Add(this.btnModuleManagement);
            this.Controls.Add(this.lblCourseMessage);
            this.Controls.Add(this.btnRemoveCourse);
            this.Controls.Add(this.flpCourseList);
            this.Controls.Add(this.lblCourseList);
            this.Controls.Add(this.tbCourseName);
            this.Controls.Add(this.btnCreateCourse);
            this.Controls.Add(this.lblNewCourse);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.lblCourseName);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_CourseManagement";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Label lblCourseName;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Label lblNewCourse;
        private System.Windows.Forms.Button btnCreateCourse;
        private System.Windows.Forms.TextBox tbCourseName;
        private System.Windows.Forms.Label lblCourseList;
        private System.Windows.Forms.FlowLayoutPanel flpCourseList;
        private System.Windows.Forms.Button btnRemoveCourse;
        private System.Windows.Forms.Label lblCourseMessage;
        private System.Windows.Forms.Button btnModuleManagement;
        private System.Windows.Forms.TextBox tbStaffUsername;
        private System.Windows.Forms.Label lblRelatedStaffMember;
        private System.Windows.Forms.Label lblPageAdvice;
    }
}
