﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using DataModel;

namespace CheatInterface_Test
{
    public partial class UserControl_AdminHomePage : UserControl
    {
        // Allowing access to functions in main class
        PageManagement pageManagement = PageManagement.GetInstance();
        AccountManager accountManager = AccountManager.GetInstance();
        DataManager dataManager = DataManager.GetInstance();

        // Set the location that the submissions are stored for future reference.
        private string submissionsFolderURL;

        // Lists for main class to access controls for colour changes
        public List<Label> labelList = new List<Label>();
        public List<Button> buttonList = new List<Button>();

        public UserControl_AdminHomePage()
        {
            InitializeComponent();

            submissionsFolderURL = dataManager.SubmissionsFolderURL;
            lblAdminMessage.Text = "";

            // Adding all labels and buttons in user control and relevant panels into list for colour changes in pageManagement class
            foreach (Label pageLabel in this.Controls.OfType<Label>())
            {
                labelList.Add(pageLabel);
            }
            foreach (Button pageButton in this.Controls.OfType<Button>())
            {
                buttonList.Add(pageButton);
            }
            foreach (FlowLayoutPanel pagePanel in this.Controls.OfType<FlowLayoutPanel>())
            {
                foreach (Label panelLabel in pagePanel.Controls.OfType<Label>())
                {
                    labelList.Add(panelLabel);
                }
                foreach (Button panelButton in pagePanel.Controls.OfType<Button>())
                {
                    buttonList.Add(panelButton);
                }
            }
            pageManagement.AddToPageLabels(labelList);
            pageManagement.AddToPageButtons(buttonList);

            // Clear lists after use as they are no longer needed
            labelList.Clear();
            buttonList.Clear();
            this.VisibleChanged += new EventHandler(this.UserControlVisibleChanged);
        }

        private void UserControlVisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true && accountManager.accountLoggedIn != null)
            {
                lblAdminMessage.Text = "";
            }
        }

        private void btnSelectAssignment_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AdminHome", "SelectAssignment");
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AdminHome", "CreateAccount");
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AdminHome", "Settings");
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            accountManager.accountLoggedIn = null;
            pageManagement.ChangePage("AdminHome", "Login");
        }

        private void btnBackTop_Click(object sender, EventArgs e)
        {
            pageManagement.BackButton("AdminHome");
        }

        private void btnForwardTop_Click(object sender, EventArgs e)
        {
            pageManagement.ForwardButton("AdminHome");
        }

        private void btnModuleManagement_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AdminHome", "ModuleManagement");
        }

        private void btnLoadStaff_Click(object sender, EventArgs e)
        {
            if (accountManager.AcceptStaffFromFile(submissionsFolderURL + "staff.txt"))
            {
                lblAdminMessage.Text = "Staff information successfully loaded";
            }
            else
            {
                lblAdminMessage.Text = "Staff information could not load";
            }
            
        }

        private void btnLoadModules_Click(object sender, EventArgs e)
        {
            if (dataManager.AcceptModulesFromFile(submissionsFolderURL + "modules.txt"))
            {
                lblAdminMessage.Text = "Module information successfully loaded";
            }
            else
            {
                lblAdminMessage.Text = "Module information could not load";
            }
        }

        private void btnManageCourses_Click(object sender, EventArgs e)
        {
            pageManagement.ChangePage("AdminHome", "CourseManagement");
        }

        private void btnLoadCourses_Click(object sender, EventArgs e)
        {
            if (dataManager.AcceptCoursesFromFile(submissionsFolderURL + "courses.txt"))
            {
                lblAdminMessage.Text = "Course information successfully loaded";
            }
            else
            {
                lblAdminMessage.Text = "Course information could not load";
            }
        }

        private void btnLoadAssignments_Click(object sender, EventArgs e)
        {
            if (accountManager.AcceptAssignmentsFromFile(submissionsFolderURL + "assignments.txt"))
            {
                lblAdminMessage.Text = "Assignment information successfully loaded";
            }
            else
            {
                lblAdminMessage.Text = "Assignment information could not load";
            }
        }

        private void btnLoadStudents_Click(object sender, EventArgs e)
        {
            if (accountManager.AcceptStudentsFromFile(submissionsFolderURL + "students.txt"))
            {
                lblAdminMessage.Text = "Student information successfully loaded";
            }
            else
            {
                lblAdminMessage.Text = "Student information could not load";
            }
        }

        private void btnSaveStaff_Click(object sender, EventArgs e)
        {
            accountManager.SaveStaff(submissionsFolderURL + "staff.txt");
        }

        private void btnSaveStudents_Click(object sender, EventArgs e)
        {
            accountManager.SaveStudents(submissionsFolderURL + "students.txt");
        }

        private void btnSaveCourse_Click(object sender, EventArgs e)
        {
            dataManager.SaveCourses(submissionsFolderURL + "courses.txt");
        }

        private void btnSaveModules_Click(object sender, EventArgs e)
        {
            dataManager.SaveModules(submissionsFolderURL + "modules.txt");
        }

        private void btnSaveAssignments_Click(object sender, EventArgs e)
        {
            accountManager.SaveAssignments(submissionsFolderURL + "assignments.txt");
        }
    }
}
