﻿namespace CheatInterface_Test
{
    partial class UserControl_CreateAccount
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlpField = new System.Windows.Forms.TableLayoutPanel();
            this.tbSecretWord = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblSecretWord = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblUserDetails = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnDeleteAccount = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.flpAccountList = new System.Windows.Forms.FlowLayoutPanel();
            this.lblSelectedUserPassword = new System.Windows.Forms.Label();
            this.lblSelectedUserDetails = new System.Windows.Forms.Label();
            this.lblSelectedUserEmail = new System.Windows.Forms.Label();
            this.lbllblSelectedUserSecretWord = new System.Windows.Forms.Label();
            this.lbllblSelectedUserAccountType = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tlpSelectedUser = new System.Windows.Forms.TableLayoutPanel();
            this.lblSelectedUserLastNameText = new System.Windows.Forms.Label();
            this.lblSelectedUserFirstNameText = new System.Windows.Forms.Label();
            this.lblSelectedUserLastName = new System.Windows.Forms.Label();
            this.lblSelectedUserFirstName = new System.Windows.Forms.Label();
            this.lblSelectedUserAccountTypeText = new System.Windows.Forms.Label();
            this.lblSelectedUserSecretWordText = new System.Windows.Forms.Label();
            this.lblSelectedUserPasswordText = new System.Windows.Forms.Label();
            this.lblSelectedUserUsernameText = new System.Windows.Forms.Label();
            this.lblSelectedUserEmailText = new System.Windows.Forms.Label();
            this.lblMessageBadInput = new System.Windows.Forms.Label();
            this.lblMessageCantWithAdmin = new System.Windows.Forms.Label();
            this.btnModuleManagement = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.btnAllocateModules = new System.Windows.Forms.Button();
            this.btnManageCourses = new System.Windows.Forms.Button();
            this.tlpField.SuspendLayout();
            this.tlpSelectedUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlpField
            // 
            this.tlpField.ColumnCount = 2;
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28F));
            this.tlpField.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72F));
            this.tlpField.Controls.Add(this.tbSecretWord, 1, 5);
            this.tlpField.Controls.Add(this.tbEmail, 1, 4);
            this.tlpField.Controls.Add(this.tbPassword, 1, 3);
            this.tlpField.Controls.Add(this.tbLastName, 1, 2);
            this.tlpField.Controls.Add(this.tbFirstName, 1, 1);
            this.tlpField.Controls.Add(this.tbUsername, 1, 0);
            this.tlpField.Controls.Add(this.lblUserName, 0, 0);
            this.tlpField.Controls.Add(this.lblSecretWord, 0, 5);
            this.tlpField.Controls.Add(this.lblEmail, 0, 4);
            this.tlpField.Controls.Add(this.lblPassword, 0, 3);
            this.tlpField.Controls.Add(this.lblLastName, 0, 2);
            this.tlpField.Controls.Add(this.lblFirstName, 0, 1);
            this.tlpField.Location = new System.Drawing.Point(3, 150);
            this.tlpField.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tlpField.Name = "tlpField";
            this.tlpField.RowCount = 6;
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tlpField.Size = new System.Drawing.Size(425, 267);
            this.tlpField.TabIndex = 71;
            // 
            // tbSecretWord
            // 
            this.tbSecretWord.Location = new System.Drawing.Point(122, 223);
            this.tbSecretWord.Name = "tbSecretWord";
            this.tbSecretWord.Size = new System.Drawing.Size(300, 26);
            this.tbSecretWord.TabIndex = 104;
            this.tbSecretWord.TextChanged += new System.EventHandler(this.tbSecretWord_TextChanged);
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(122, 179);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(300, 26);
            this.tbEmail.TabIndex = 103;
            this.tbEmail.TextChanged += new System.EventHandler(this.tbEmail_TextChanged);
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(122, 135);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(300, 26);
            this.tbPassword.TabIndex = 102;
            this.tbPassword.TextChanged += new System.EventHandler(this.tbPassword_TextChanged);
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(122, 91);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(300, 26);
            this.tbLastName.TabIndex = 101;
            this.tbLastName.TextChanged += new System.EventHandler(this.tbLastName_TextChanged);
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(122, 47);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(300, 26);
            this.tbFirstName.TabIndex = 100;
            this.tbFirstName.TextChanged += new System.EventHandler(this.tbFirstName_TextChanged);
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(122, 3);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(300, 26);
            this.tbUsername.TabIndex = 97;
            this.tbUsername.TextChanged += new System.EventHandler(this.tbUsername_TextChanged);
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(4, 0);
            this.lblUserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(87, 20);
            this.lblUserName.TabIndex = 99;
            this.lblUserName.Text = "Username:";
            // 
            // lblSecretWord
            // 
            this.lblSecretWord.AutoSize = true;
            this.lblSecretWord.Location = new System.Drawing.Point(4, 220);
            this.lblSecretWord.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSecretWord.Name = "lblSecretWord";
            this.lblSecretWord.Size = new System.Drawing.Size(102, 20);
            this.lblSecretWord.TabIndex = 40;
            this.lblSecretWord.Text = "Secret Word:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(4, 176);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(52, 20);
            this.lblEmail.TabIndex = 39;
            this.lblEmail.Text = "Email:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(4, 132);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(82, 20);
            this.lblPassword.TabIndex = 38;
            this.lblPassword.Text = "Password:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(4, 88);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(90, 20);
            this.lblLastName.TabIndex = 97;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(4, 44);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(90, 20);
            this.lblFirstName.TabIndex = 98;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblUserDetails
            // 
            this.lblUserDetails.BackColor = System.Drawing.Color.Transparent;
            this.lblUserDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblUserDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserDetails.Location = new System.Drawing.Point(3, 111);
            this.lblUserDetails.Name = "lblUserDetails";
            this.lblUserDetails.Size = new System.Drawing.Size(425, 34);
            this.lblUserDetails.TabIndex = 70;
            this.lblUserDetails.Text = "User Details";
            // 
            // btnCreate
            // 
            this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreate.Location = new System.Drawing.Point(3, 425);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(152, 49);
            this.btnCreate.TabIndex = 69;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 68;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(252, 37);
            this.lblPageName.TabIndex = 64;
            this.lblPageName.Text = "Create Account";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 62;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 63;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 67;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnDeleteAccount
            // 
            this.btnDeleteAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteAccount.Location = new System.Drawing.Point(1235, 989);
            this.btnDeleteAccount.Name = "btnDeleteAccount";
            this.btnDeleteAccount.Size = new System.Drawing.Size(200, 50);
            this.btnDeleteAccount.TabIndex = 87;
            this.btnDeleteAccount.Text = "Delete Account";
            this.btnDeleteAccount.UseVisualStyleBackColor = true;
            this.btnDeleteAccount.Click += new System.EventHandler(this.btnDeleteAccount_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1274, 34);
            this.lblPageAdvice.TabIndex = 88;
            this.lblPageAdvice.Text = "Enter the user details to create a new account or select accounts on the right to" +
    " remove them.";
            // 
            // flpAccountList
            // 
            this.flpAccountList.AutoScroll = true;
            this.flpAccountList.Location = new System.Drawing.Point(1194, 109);
            this.flpAccountList.Name = "flpAccountList";
            this.flpAccountList.Size = new System.Drawing.Size(241, 874);
            this.flpAccountList.TabIndex = 89;
            // 
            // lblSelectedUserPassword
            // 
            this.lblSelectedUserPassword.AutoSize = true;
            this.lblSelectedUserPassword.Location = new System.Drawing.Point(4, 99);
            this.lblSelectedUserPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedUserPassword.Name = "lblSelectedUserPassword";
            this.lblSelectedUserPassword.Size = new System.Drawing.Size(82, 20);
            this.lblSelectedUserPassword.TabIndex = 91;
            this.lblSelectedUserPassword.Text = "Password:";
            // 
            // lblSelectedUserDetails
            // 
            this.lblSelectedUserDetails.AutoSize = true;
            this.lblSelectedUserDetails.Location = new System.Drawing.Point(4, 0);
            this.lblSelectedUserDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedUserDetails.Name = "lblSelectedUserDetails";
            this.lblSelectedUserDetails.Size = new System.Drawing.Size(87, 20);
            this.lblSelectedUserDetails.TabIndex = 90;
            this.lblSelectedUserDetails.Text = "Username:";
            // 
            // lblSelectedUserEmail
            // 
            this.lblSelectedUserEmail.AutoSize = true;
            this.lblSelectedUserEmail.Location = new System.Drawing.Point(4, 132);
            this.lblSelectedUserEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedUserEmail.Name = "lblSelectedUserEmail";
            this.lblSelectedUserEmail.Size = new System.Drawing.Size(52, 20);
            this.lblSelectedUserEmail.TabIndex = 92;
            this.lblSelectedUserEmail.Text = "Email:";
            // 
            // lbllblSelectedUserSecretWord
            // 
            this.lbllblSelectedUserSecretWord.AutoSize = true;
            this.lbllblSelectedUserSecretWord.Location = new System.Drawing.Point(4, 165);
            this.lbllblSelectedUserSecretWord.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbllblSelectedUserSecretWord.Name = "lbllblSelectedUserSecretWord";
            this.lbllblSelectedUserSecretWord.Size = new System.Drawing.Size(102, 20);
            this.lbllblSelectedUserSecretWord.TabIndex = 93;
            this.lbllblSelectedUserSecretWord.Text = "Secret Word:";
            // 
            // lbllblSelectedUserAccountType
            // 
            this.lbllblSelectedUserAccountType.AutoSize = true;
            this.lbllblSelectedUserAccountType.Location = new System.Drawing.Point(4, 198);
            this.lbllblSelectedUserAccountType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbllblSelectedUserAccountType.Name = "lbllblSelectedUserAccountType";
            this.lbllblSelectedUserAccountType.Size = new System.Drawing.Size(110, 20);
            this.lbllblSelectedUserAccountType.TabIndex = 94;
            this.lbllblSelectedUserAccountType.Text = "Account Type:";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(763, 712);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(425, 34);
            this.label6.TabIndex = 95;
            this.label6.Text = "Selected User Details";
            // 
            // tlpSelectedUser
            // 
            this.tlpSelectedUser.AutoSize = true;
            this.tlpSelectedUser.ColumnCount = 2;
            this.tlpSelectedUser.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpSelectedUser.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserLastNameText, 1, 2);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserFirstNameText, 1, 1);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserLastName, 0, 2);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserFirstName, 0, 1);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserDetails, 0, 0);
            this.tlpSelectedUser.Controls.Add(this.lbllblSelectedUserAccountType, 0, 6);
            this.tlpSelectedUser.Controls.Add(this.lbllblSelectedUserSecretWord, 0, 5);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserEmail, 0, 4);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserPassword, 0, 3);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserAccountTypeText, 1, 6);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserSecretWordText, 1, 5);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserPasswordText, 1, 3);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserUsernameText, 1, 0);
            this.tlpSelectedUser.Controls.Add(this.lblSelectedUserEmailText, 1, 4);
            this.tlpSelectedUser.Location = new System.Drawing.Point(763, 749);
            this.tlpSelectedUser.Name = "tlpSelectedUser";
            this.tlpSelectedUser.RowCount = 7;
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpSelectedUser.Size = new System.Drawing.Size(425, 234);
            this.tlpSelectedUser.TabIndex = 96;
            // 
            // lblSelectedUserLastNameText
            // 
            this.lblSelectedUserLastNameText.AutoSize = true;
            this.lblSelectedUserLastNameText.Location = new System.Drawing.Point(121, 66);
            this.lblSelectedUserLastNameText.Name = "lblSelectedUserLastNameText";
            this.lblSelectedUserLastNameText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserLastNameText.TabIndex = 102;
            this.lblSelectedUserLastNameText.Text = "_";
            // 
            // lblSelectedUserFirstNameText
            // 
            this.lblSelectedUserFirstNameText.AutoSize = true;
            this.lblSelectedUserFirstNameText.Location = new System.Drawing.Point(121, 33);
            this.lblSelectedUserFirstNameText.Name = "lblSelectedUserFirstNameText";
            this.lblSelectedUserFirstNameText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserFirstNameText.TabIndex = 101;
            this.lblSelectedUserFirstNameText.Text = "_";
            // 
            // lblSelectedUserLastName
            // 
            this.lblSelectedUserLastName.AutoSize = true;
            this.lblSelectedUserLastName.Location = new System.Drawing.Point(4, 66);
            this.lblSelectedUserLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedUserLastName.Name = "lblSelectedUserLastName";
            this.lblSelectedUserLastName.Size = new System.Drawing.Size(90, 20);
            this.lblSelectedUserLastName.TabIndex = 99;
            this.lblSelectedUserLastName.Text = "Last Name:";
            // 
            // lblSelectedUserFirstName
            // 
            this.lblSelectedUserFirstName.AutoSize = true;
            this.lblSelectedUserFirstName.Location = new System.Drawing.Point(4, 33);
            this.lblSelectedUserFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedUserFirstName.Name = "lblSelectedUserFirstName";
            this.lblSelectedUserFirstName.Size = new System.Drawing.Size(90, 20);
            this.lblSelectedUserFirstName.TabIndex = 99;
            this.lblSelectedUserFirstName.Text = "First Name:";
            // 
            // lblSelectedUserAccountTypeText
            // 
            this.lblSelectedUserAccountTypeText.AutoSize = true;
            this.lblSelectedUserAccountTypeText.Location = new System.Drawing.Point(121, 198);
            this.lblSelectedUserAccountTypeText.Name = "lblSelectedUserAccountTypeText";
            this.lblSelectedUserAccountTypeText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserAccountTypeText.TabIndex = 99;
            this.lblSelectedUserAccountTypeText.Text = "_";
            // 
            // lblSelectedUserSecretWordText
            // 
            this.lblSelectedUserSecretWordText.AutoSize = true;
            this.lblSelectedUserSecretWordText.Location = new System.Drawing.Point(121, 165);
            this.lblSelectedUserSecretWordText.Name = "lblSelectedUserSecretWordText";
            this.lblSelectedUserSecretWordText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserSecretWordText.TabIndex = 100;
            this.lblSelectedUserSecretWordText.Text = "_";
            // 
            // lblSelectedUserPasswordText
            // 
            this.lblSelectedUserPasswordText.AutoSize = true;
            this.lblSelectedUserPasswordText.Location = new System.Drawing.Point(121, 99);
            this.lblSelectedUserPasswordText.Name = "lblSelectedUserPasswordText";
            this.lblSelectedUserPasswordText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserPasswordText.TabIndex = 97;
            this.lblSelectedUserPasswordText.Text = "_";
            // 
            // lblSelectedUserUsernameText
            // 
            this.lblSelectedUserUsernameText.AutoSize = true;
            this.lblSelectedUserUsernameText.Location = new System.Drawing.Point(121, 0);
            this.lblSelectedUserUsernameText.Name = "lblSelectedUserUsernameText";
            this.lblSelectedUserUsernameText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserUsernameText.TabIndex = 95;
            this.lblSelectedUserUsernameText.Text = "_";
            // 
            // lblSelectedUserEmailText
            // 
            this.lblSelectedUserEmailText.AutoSize = true;
            this.lblSelectedUserEmailText.Location = new System.Drawing.Point(121, 132);
            this.lblSelectedUserEmailText.Name = "lblSelectedUserEmailText";
            this.lblSelectedUserEmailText.Size = new System.Drawing.Size(18, 20);
            this.lblSelectedUserEmailText.TabIndex = 98;
            this.lblSelectedUserEmailText.Text = "_";
            // 
            // lblMessageBadInput
            // 
            this.lblMessageBadInput.AutoSize = true;
            this.lblMessageBadInput.Location = new System.Drawing.Point(3, 477);
            this.lblMessageBadInput.Name = "lblMessageBadInput";
            this.lblMessageBadInput.Size = new System.Drawing.Size(18, 20);
            this.lblMessageBadInput.TabIndex = 97;
            this.lblMessageBadInput.Text = "_";
            // 
            // lblMessageCantWithAdmin
            // 
            this.lblMessageCantWithAdmin.AutoSize = true;
            this.lblMessageCantWithAdmin.Location = new System.Drawing.Point(767, 682);
            this.lblMessageCantWithAdmin.Name = "lblMessageCantWithAdmin";
            this.lblMessageCantWithAdmin.Size = new System.Drawing.Size(243, 20);
            this.lblMessageCantWithAdmin.TabIndex = 98;
            this.lblMessageCantWithAdmin.Text = "Cannot delete an admin account.";
            // 
            // btnModuleManagement
            // 
            this.btnModuleManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModuleManagement.Location = new System.Drawing.Point(967, 3);
            this.btnModuleManagement.Name = "btnModuleManagement";
            this.btnModuleManagement.Size = new System.Drawing.Size(152, 49);
            this.btnModuleManagement.TabIndex = 99;
            this.btnModuleManagement.Text = "Manage Modules";
            this.btnModuleManagement.UseVisualStyleBackColor = true;
            this.btnModuleManagement.Click += new System.EventHandler(this.btnModuleManagement_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 65;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // btnAllocateModules
            // 
            this.btnAllocateModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAllocateModules.Location = new System.Drawing.Point(988, 989);
            this.btnAllocateModules.Name = "btnAllocateModules";
            this.btnAllocateModules.Size = new System.Drawing.Size(200, 50);
            this.btnAllocateModules.TabIndex = 100;
            this.btnAllocateModules.Text = "Allocate Modules";
            this.btnAllocateModules.UseVisualStyleBackColor = true;
            this.btnAllocateModules.Click += new System.EventHandler(this.btnAllocateModules_Click);
            // 
            // btnManageCourses
            // 
            this.btnManageCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCourses.Location = new System.Drawing.Point(797, 3);
            this.btnManageCourses.Name = "btnManageCourses";
            this.btnManageCourses.Size = new System.Drawing.Size(164, 49);
            this.btnManageCourses.TabIndex = 103;
            this.btnManageCourses.Text = "Manage Courses";
            this.btnManageCourses.UseVisualStyleBackColor = true;
            this.btnManageCourses.Click += new System.EventHandler(this.btnManageCourses_Click);
            // 
            // UserControl_CreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnManageCourses);
            this.Controls.Add(this.btnAllocateModules);
            this.Controls.Add(this.btnModuleManagement);
            this.Controls.Add(this.lblMessageCantWithAdmin);
            this.Controls.Add(this.lblMessageBadInput);
            this.Controls.Add(this.tlpSelectedUser);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.flpAccountList);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.btnDeleteAccount);
            this.Controls.Add(this.tlpField);
            this.Controls.Add(this.lblUserDetails);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_CreateAccount";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.tlpField.ResumeLayout(false);
            this.tlpField.PerformLayout();
            this.tlpSelectedUser.ResumeLayout(false);
            this.tlpSelectedUser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tlpField;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSecretWord;
        private System.Windows.Forms.Label lblUserDetails;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnDeleteAccount;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.FlowLayoutPanel flpAccountList;
        private System.Windows.Forms.Label lblSelectedUserPassword;
        private System.Windows.Forms.Label lblSelectedUserDetails;
        private System.Windows.Forms.Label lblSelectedUserEmail;
        private System.Windows.Forms.Label lbllblSelectedUserSecretWord;
        private System.Windows.Forms.Label lbllblSelectedUserAccountType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tlpSelectedUser;
        private System.Windows.Forms.Label lblSelectedUserAccountTypeText;
        private System.Windows.Forms.Label lblSelectedUserSecretWordText;
        private System.Windows.Forms.Label lblSelectedUserEmailText;
        private System.Windows.Forms.Label lblSelectedUserPasswordText;
        private System.Windows.Forms.Label lblSelectedUserUsernameText;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblSelectedUserLastNameText;
        private System.Windows.Forms.Label lblSelectedUserFirstNameText;
        private System.Windows.Forms.Label lblSelectedUserLastName;
        private System.Windows.Forms.Label lblSelectedUserFirstName;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.TextBox tbSecretWord;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.Label lblMessageBadInput;
        private System.Windows.Forms.Label lblMessageCantWithAdmin;
        private System.Windows.Forms.Button btnModuleManagement;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Button btnAllocateModules;
        private System.Windows.Forms.Button btnManageCourses;
    }
}
