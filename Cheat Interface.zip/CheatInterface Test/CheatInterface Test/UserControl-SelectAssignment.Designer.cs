﻿namespace CheatInterface_Test
{
    partial class UserControl_SelectAssignment
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpModules = new System.Windows.Forms.FlowLayoutPanel();
            this.flpCourses = new System.Windows.Forms.FlowLayoutPanel();
            this.lblAllModules = new System.Windows.Forms.Label();
            this.lblCourses = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.lblPageAdvice = new System.Windows.Forms.Label();
            this.lblModules = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnSelectAssignment = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.flpAllModules = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // flpModules
            // 
            this.flpModules.AutoScroll = true;
            this.flpModules.BackColor = System.Drawing.Color.White;
            this.flpModules.Location = new System.Drawing.Point(346, 160);
            this.flpModules.Name = "flpModules";
            this.flpModules.Size = new System.Drawing.Size(318, 866);
            this.flpModules.TabIndex = 69;
            // 
            // flpCourses
            // 
            this.flpCourses.AutoScroll = true;
            this.flpCourses.BackColor = System.Drawing.Color.White;
            this.flpCourses.Location = new System.Drawing.Point(3, 160);
            this.flpCourses.Name = "flpCourses";
            this.flpCourses.Size = new System.Drawing.Size(318, 866);
            this.flpCourses.TabIndex = 68;
            // 
            // lblAllModules
            // 
            this.lblAllModules.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblAllModules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAllModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAllModules.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllModules.Location = new System.Drawing.Point(691, 119);
            this.lblAllModules.Name = "lblAllModules";
            this.lblAllModules.Size = new System.Drawing.Size(744, 34);
            this.lblAllModules.TabIndex = 66;
            this.lblAllModules.Text = "All Modules                ";
            // 
            // lblCourses
            // 
            this.lblCourses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblCourses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCourses.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourses.Location = new System.Drawing.Point(3, 119);
            this.lblCourses.Name = "lblCourses";
            this.lblCourses.Size = new System.Drawing.Size(318, 34);
            this.lblCourses.TabIndex = 65;
            this.lblCourses.Text = "Courses                          ";
            // 
            // btnContinue
            // 
            this.btnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinue.Location = new System.Drawing.Point(1283, 60);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(152, 49);
            this.btnContinue.TabIndex = 64;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // lblPageAdvice
            // 
            this.lblPageAdvice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPageAdvice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageAdvice.Location = new System.Drawing.Point(3, 65);
            this.lblPageAdvice.Name = "lblPageAdvice";
            this.lblPageAdvice.Size = new System.Drawing.Size(1274, 34);
            this.lblPageAdvice.TabIndex = 63;
            this.lblPageAdvice.Text = "Select the module for the assignment submissions you would like to see.";
            // 
            // lblModules
            // 
            this.lblModules.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lblModules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblModules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblModules.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModules.Location = new System.Drawing.Point(347, 119);
            this.lblModules.Name = "lblModules";
            this.lblModules.Size = new System.Drawing.Size(317, 34);
            this.lblModules.TabIndex = 62;
            this.lblModules.Text = "Modules                         ";
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 60;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 59;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnSelectAssignment
            // 
            this.btnSelectAssignment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectAssignment.Location = new System.Drawing.Point(959, 3);
            this.btnSelectAssignment.Name = "btnSelectAssignment";
            this.btnSelectAssignment.Size = new System.Drawing.Size(160, 49);
            this.btnSelectAssignment.TabIndex = 58;
            this.btnSelectAssignment.Text = "Select Assignment";
            this.btnSelectAssignment.UseVisualStyleBackColor = true;
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 57;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(315, 37);
            this.lblPageName.TabIndex = 56;
            this.lblPageName.Text = "Select Assignments";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 54;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 55;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // flpAllModules
            // 
            this.flpAllModules.AutoScroll = true;
            this.flpAllModules.BackColor = System.Drawing.Color.White;
            this.flpAllModules.Location = new System.Drawing.Point(691, 160);
            this.flpAllModules.Name = "flpAllModules";
            this.flpAllModules.Size = new System.Drawing.Size(744, 866);
            this.flpAllModules.TabIndex = 72;
            // 
            // UserControl_SelectAssignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flpAllModules);
            this.Controls.Add(this.flpModules);
            this.Controls.Add(this.flpCourses);
            this.Controls.Add(this.lblAllModules);
            this.Controls.Add(this.lblCourses);
            this.Controls.Add(this.btnContinue);
            this.Controls.Add(this.lblPageAdvice);
            this.Controls.Add(this.lblModules);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnSelectAssignment);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "UserControl_SelectAssignment";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flpModules;
        private System.Windows.Forms.FlowLayoutPanel flpCourses;
        private System.Windows.Forms.Label lblAllModules;
        private System.Windows.Forms.Label lblCourses;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Label lblPageAdvice;
        private System.Windows.Forms.Label lblModules;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnSelectAssignment;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.FlowLayoutPanel flpAllModules;
    }
}
