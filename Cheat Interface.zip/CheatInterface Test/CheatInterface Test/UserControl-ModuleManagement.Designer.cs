﻿namespace CheatInterface_Test
{
    partial class ModuleManagement
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNewModule = new System.Windows.Forms.Label();
            this.btnCreateModule = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnHomePage = new System.Windows.Forms.Button();
            this.lblPageName = new System.Windows.Forms.Label();
            this.btnBackTop = new System.Windows.Forms.Button();
            this.btnForwardTop = new System.Windows.Forms.Button();
            this.lblModuleName = new System.Windows.Forms.Label();
            this.lblModuleList = new System.Windows.Forms.Label();
            this.lblModuleMessage = new System.Windows.Forms.Label();
            this.tbModuleName = new System.Windows.Forms.TextBox();
            this.flpModuleList = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRemoveModule = new System.Windows.Forms.Button();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.tbAssociatedCourse = new System.Windows.Forms.TextBox();
            this.lblAssociatedCourse = new System.Windows.Forms.Label();
            this.btnManageCourses = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNewModule
            // 
            this.lblNewModule.BackColor = System.Drawing.Color.Transparent;
            this.lblNewModule.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNewModule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNewModule.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewModule.Location = new System.Drawing.Point(3, 69);
            this.lblNewModule.Name = "lblNewModule";
            this.lblNewModule.Size = new System.Drawing.Size(461, 34);
            this.lblNewModule.TabIndex = 80;
            this.lblNewModule.Text = "New Module";
            // 
            // btnCreateModule
            // 
            this.btnCreateModule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateModule.Location = new System.Drawing.Point(470, 106);
            this.btnCreateModule.Name = "btnCreateModule";
            this.btnCreateModule.Size = new System.Drawing.Size(152, 49);
            this.btnCreateModule.TabIndex = 79;
            this.btnCreateModule.Text = "Create Module";
            this.btnCreateModule.UseVisualStyleBackColor = true;
            this.btnCreateModule.Click += new System.EventHandler(this.btnCreateModule_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Location = new System.Drawing.Point(1283, 3);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(152, 49);
            this.btnLogOut.TabIndex = 78;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Location = new System.Drawing.Point(1125, 3);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 49);
            this.btnSettings.TabIndex = 77;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnHomePage
            // 
            this.btnHomePage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHomePage.Location = new System.Drawing.Point(565, 3);
            this.btnHomePage.Name = "btnHomePage";
            this.btnHomePage.Size = new System.Drawing.Size(152, 49);
            this.btnHomePage.TabIndex = 76;
            this.btnHomePage.Text = "Home Page";
            this.btnHomePage.UseVisualStyleBackColor = true;
            this.btnHomePage.Click += new System.EventHandler(this.btnHomePage_Click);
            // 
            // lblPageName
            // 
            this.lblPageName.AutoSize = true;
            this.lblPageName.BackColor = System.Drawing.Color.Transparent;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.Location = new System.Drawing.Point(195, 9);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(333, 37);
            this.lblPageName.TabIndex = 75;
            this.lblPageName.Text = "Module Management";
            // 
            // btnBackTop
            // 
            this.btnBackTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBackTop.Location = new System.Drawing.Point(3, 3);
            this.btnBackTop.Name = "btnBackTop";
            this.btnBackTop.Size = new System.Drawing.Size(86, 49);
            this.btnBackTop.TabIndex = 73;
            this.btnBackTop.Text = "<--";
            this.btnBackTop.UseVisualStyleBackColor = true;
            this.btnBackTop.Click += new System.EventHandler(this.btnBackTop_Click);
            // 
            // btnForwardTop
            // 
            this.btnForwardTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForwardTop.Location = new System.Drawing.Point(95, 3);
            this.btnForwardTop.Name = "btnForwardTop";
            this.btnForwardTop.Size = new System.Drawing.Size(86, 49);
            this.btnForwardTop.TabIndex = 74;
            this.btnForwardTop.Text = "-->";
            this.btnForwardTop.UseVisualStyleBackColor = true;
            this.btnForwardTop.Click += new System.EventHandler(this.btnForwardTop_Click);
            // 
            // lblModuleName
            // 
            this.lblModuleName.AutoSize = true;
            this.lblModuleName.Location = new System.Drawing.Point(7, 109);
            this.lblModuleName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModuleName.Name = "lblModuleName";
            this.lblModuleName.Size = new System.Drawing.Size(111, 20);
            this.lblModuleName.TabIndex = 83;
            this.lblModuleName.Text = "Module Name:";
            // 
            // lblModuleList
            // 
            this.lblModuleList.BackColor = System.Drawing.Color.Transparent;
            this.lblModuleList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblModuleList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblModuleList.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModuleList.Location = new System.Drawing.Point(1074, 69);
            this.lblModuleList.Name = "lblModuleList";
            this.lblModuleList.Size = new System.Drawing.Size(361, 34);
            this.lblModuleList.TabIndex = 85;
            this.lblModuleList.Text = "Module List";
            // 
            // lblModuleMessage
            // 
            this.lblModuleMessage.AutoSize = true;
            this.lblModuleMessage.Location = new System.Drawing.Point(7, 179);
            this.lblModuleMessage.Name = "lblModuleMessage";
            this.lblModuleMessage.Size = new System.Drawing.Size(18, 20);
            this.lblModuleMessage.TabIndex = 87;
            this.lblModuleMessage.Text = "_";
            // 
            // tbModuleName
            // 
            this.tbModuleName.Location = new System.Drawing.Point(161, 106);
            this.tbModuleName.Name = "tbModuleName";
            this.tbModuleName.Size = new System.Drawing.Size(303, 26);
            this.tbModuleName.TabIndex = 88;
            this.tbModuleName.TextChanged += new System.EventHandler(this.tbModuleName_TextChanged);
            // 
            // flpModuleList
            // 
            this.flpModuleList.Location = new System.Drawing.Point(1074, 106);
            this.flpModuleList.Name = "flpModuleList";
            this.flpModuleList.Size = new System.Drawing.Size(361, 881);
            this.flpModuleList.TabIndex = 89;
            // 
            // btnRemoveModule
            // 
            this.btnRemoveModule.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveModule.Location = new System.Drawing.Point(1235, 993);
            this.btnRemoveModule.Name = "btnRemoveModule";
            this.btnRemoveModule.Size = new System.Drawing.Size(200, 49);
            this.btnRemoveModule.TabIndex = 90;
            this.btnRemoveModule.Text = "Remove Module";
            this.btnRemoveModule.UseVisualStyleBackColor = true;
            this.btnRemoveModule.Click += new System.EventHandler(this.btnRemoveModule_Click);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateAccount.Location = new System.Drawing.Point(955, 3);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(164, 49);
            this.btnCreateAccount.TabIndex = 91;
            this.btnCreateAccount.Text = "Manage Accounts";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // tbAssociatedCourse
            // 
            this.tbAssociatedCourse.Location = new System.Drawing.Point(161, 146);
            this.tbAssociatedCourse.Name = "tbAssociatedCourse";
            this.tbAssociatedCourse.Size = new System.Drawing.Size(303, 26);
            this.tbAssociatedCourse.TabIndex = 93;
            this.tbAssociatedCourse.TextChanged += new System.EventHandler(this.tbAssociatedCourse_TextChanged);
            // 
            // lblAssociatedCourse
            // 
            this.lblAssociatedCourse.AutoSize = true;
            this.lblAssociatedCourse.Location = new System.Drawing.Point(7, 149);
            this.lblAssociatedCourse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAssociatedCourse.Name = "lblAssociatedCourse";
            this.lblAssociatedCourse.Size = new System.Drawing.Size(147, 20);
            this.lblAssociatedCourse.TabIndex = 92;
            this.lblAssociatedCourse.Text = "Associated Course:";
            // 
            // btnManageCourses
            // 
            this.btnManageCourses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCourses.Location = new System.Drawing.Point(785, 3);
            this.btnManageCourses.Name = "btnManageCourses";
            this.btnManageCourses.Size = new System.Drawing.Size(164, 49);
            this.btnManageCourses.TabIndex = 104;
            this.btnManageCourses.Text = "Manage Courses";
            this.btnManageCourses.UseVisualStyleBackColor = true;
            this.btnManageCourses.Click += new System.EventHandler(this.btnManageCourses_Click);
            // 
            // ModuleManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnManageCourses);
            this.Controls.Add(this.tbAssociatedCourse);
            this.Controls.Add(this.lblAssociatedCourse);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.btnRemoveModule);
            this.Controls.Add(this.flpModuleList);
            this.Controls.Add(this.tbModuleName);
            this.Controls.Add(this.lblModuleMessage);
            this.Controls.Add(this.lblModuleList);
            this.Controls.Add(this.lblModuleName);
            this.Controls.Add(this.lblNewModule);
            this.Controls.Add(this.btnCreateModule);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnHomePage);
            this.Controls.Add(this.lblPageName);
            this.Controls.Add(this.btnBackTop);
            this.Controls.Add(this.btnForwardTop);
            this.Name = "ModuleManagement";
            this.Size = new System.Drawing.Size(1450, 1050);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblNewModule;
        private System.Windows.Forms.Button btnCreateModule;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnHomePage;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Button btnBackTop;
        private System.Windows.Forms.Button btnForwardTop;
        private System.Windows.Forms.Label lblModuleName;
        private System.Windows.Forms.Label lblModuleList;
        private System.Windows.Forms.Label lblModuleMessage;
        private System.Windows.Forms.TextBox tbModuleName;
        private System.Windows.Forms.FlowLayoutPanel flpModuleList;
        private System.Windows.Forms.Button btnRemoveModule;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.TextBox tbAssociatedCourse;
        private System.Windows.Forms.Label lblAssociatedCourse;
        private System.Windows.Forms.Button btnManageCourses;
    }
}
